module CSV where

import Text.Parsec
import Text.Parsec.String

{-
An informal BNF for comma-separated values (CSV)

<csv> ::= <line> '\n' <line> '\n' ... '\n' <line>

<line> ::= <value> ',' <value> ',' ... ',' <value>

<value> ::= <plain> | <quoted>

<plain> ::= zero or more characters EXCLUDING commas (','), quotes ('"'), and newlines ('\n')

<quoted> ::= '"' quotation '"'

<quotation> ::= zero or more characters EXCLUDING '"'
-}

-- A CSV file can be represented by a structured type containing a list of list
-- of values, where each value is a string.

type Value = String

type CSV = [[Value]]

-- The Parsec parser for CSV follows the above informal description by
-- translating each part to a primitive parser or parser combinator.
csv :: Parser CSV
csv = line `sepBy` newline
-- The 'sepBy' combinator represents many of the first parser, each separated by
-- the second parser. In the case of csv, this is *almost* the same thing as
--
--     many (do { l <- line; newline; return l})
--
-- except that the final 'newline' is not run. This is because 'newline' is
-- expected *between* each line, not *after* each line.


line :: Parser [Value]
line = value `sepBy` comma

comma :: Parser Char
comma = char ','

value :: Parser Value
value = quoted <|> plain

plain :: Parser Value
plain = many (noneOf ",\"\n\r")
-- The 'noneOf' parser consumes and returns a single character which is *not*
-- found in the given list. Here, a 'plain' value is any sequence of characters
-- which are *not* in the string ",\"\n\r".

quoted :: Parser Value
quoted = do
  char '"'
  v <- many (noneOf "\"")
  char '"'
  return v
