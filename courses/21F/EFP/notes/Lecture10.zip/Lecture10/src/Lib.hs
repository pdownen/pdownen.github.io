module Lib where

import Text.Parsec
import Text.Parsec.String

-- The type Parser a represents and action which consumes a portion of an input
-- string (which is an implicit and unnamed input to the action), producing a
-- value of type 'a' as a result.

-- The "empty" parser which consumes no input (and doesn't return anything of
-- interest), often written as the greek letter epsilon.
epsilon :: Parser ()
epsilon = return ()

-- Two parsers can be run one after another in sequence by using a do
-- expression. Any remaining portion of the String being parsed which is not
-- consumed by the first parser is implicitly passed along to the second parser.

-- 'ab' parses the character 'a' first, then 'b' second, and returns both
-- characters.
ab :: Parser (Char, Char)
ab = do a <- char 'a'
        b <- char 'b'
        return (a, b)

-- The 'eof' parser signifies that the String being parsed has been completely
-- consumed, and there is nothing left. This lets you write a parser which
-- expects to consume its entire input, without anything remaining, like when
-- parsing the entire contents of a file.

-- For example, this parses *exactly* the string "ab", and nothing else.
exactly_ab :: Parser (Char, Char)
exactly_ab = do
  x <- ab
  eof
  return x

-- 'ba' is like 'ab', except the other way around.
ba = do b <- char 'b'
        a <- char 'a'
        return (b, a)

-- When parsing, you typically have to choose between one of many options,
-- depending on the text. This is handled with the alternative operator (<|>).
-- Given two parsers p1 and p2, p1 <|> p2 will run *either* p1 or p2, depending
-- on which one succeeds.  If p1 fails on the current input, but p2 succeeds,
-- then p1 <|> p2 will run p2 and return its result, and vice versa.  Because
-- you don't know in advance which of p1 or p2 will run, they both must return
-- the same type of result.

-- For example, we can run either 'ab' or 'ba' depending on the input string, so
-- that both the strings "ab" and "ba" are successfully parsed.  Since you can't
-- know in advance which one will run, we learn after parsing by inspecting the
-- returned result of the parser.
abOrba :: Parser (Char, Char)
abOrba = ab <|> ba

-- A parser can be run many times, consuming more and more of the input each
-- time, until it no longer applies. The 'many' function from Parsec takes a
-- 'Parser a' and gives back a 'Parser [a]', which runs the given parser zero or
-- more times (as many as possible for the input String) and returns a list
-- containing the result of each time the parser was run. Since 'many' turns one
-- Parser into another Parser, it is also referred to as a "combinator" (because
-- it combines basic parsers together to produce more complex ones).
lotsOfabOrba :: Parser [(Char, Char)]
lotsOfabOrba = many abOrba
-- If you want to run a parser one or more times (instead of zero or more), you
-- can use many1 instead of many. The only difference between many1 and many is
-- that 'many1 p' will fail if 'p' cannot be run even once, and so 'many1 p'
-- will never return an empty list.

-- A Parsec Parser is capable of checking for balancing like with parentheses,
-- brackets, or quotation marks.  For example, a balanced string of parenthesis
-- corresponds to a "rose tree", which is a generalization of binary trees where
-- every node can have any number (zero or more) of children.  A Haskell data
-- type representing rose trees is:
data Rose = Node [Rose] deriving Show

-- In order to balanced string of parenthesis, you can make a recursive call to
-- have a balanced string in between an open and closed parentheses.  'balanced'
-- represents a parser that accepts exactly one balanced parentheses tree
-- starting with an '(' and ending with a ')', and many_balanced represents a
-- list of many balanced parentheses trees written one right after the other.
balanced :: Parser Rose
balanced = do
  char '('
  children <- many_balanced
  char ')'
  return (Node children)

many_balanced :: Parser [Rose]
many_balanced = many balanced


-- You can convert textual information (like a string of many digits) into
-- information that reflects its structure (like an integer corresponding to
-- those digits). This makes the information contained within a string more
-- useful by removing the many possibilities for improperly written strings and
-- containing only the interesting part.
digits :: Parser String
digits = many1 digit -- 'digit' comes from Text.Parsec

number :: Parser Integer
number = do
  n <- digits
  return (read n)

-- You can write your own "combinator" by writing functions which accept one or
-- more parsers and input, and return another parser.  For example, the `times`
-- function repeats a given parser an exact number of times.
times :: Integer -> Parser a -> Parser [a]
0 `times` parse = return []
n `times` parse = do
  x <- parse
  xs <- (n-1) `times` parse
  return (x:xs)

-- What does this parser do?
mystery = do
  n <- number
  if n > 0
    then do first <- letter -- 'letter' is from Text.Parsec, parses a letter
            (n-1) `times` char first
            char '.'
            return (n, first)
    else fail "expected a number greater than 0"
-- Note that this goes well beyond the capabilities of regular expressions and
-- context-free grammars!

-- The big main tricky part of using Parsec is that when there is a choice of
-- parsers (by using the <|> alternative operator), there is no backtracking by
-- default.  For example, consider the aaOrab parser.
aa :: Parser (Char, Char)
aa = do
  a1 <- char 'a'
  a2 <- char 'a'
  return (a1, a2)

aaOrab_wrong :: Parser (Char, Char)
aaOrab_wrong = aa <|> ab
-- Surprisingly, testing aaOrab on the string "ab" will fail, even though
-- running ab directly on that string would have succeeded! Why is that? Because
-- given a choice between the two parsers aa <|> ab, once aa begins to consume
-- some input, Parsec will *commit* to aa and not backtrack if it fails in the
-- middle. Since aa will consume the first 'a' of "ab", that means that
-- aaOrab_wrong commits to the choice of ab and ab will never get a chance. One
-- solution to this problem is to factor out the common prefix between the two
-- parsers, like so
aaOrab_right :: Parser (Char, Char)
aaOrab_right = do
  a <- char 'a'
  x <- char 'a' <|> char 'b'
  return (a, x)
-- This now does the right thing for the input "ab", but it is very clunky: I
-- couldn't just use aa and ab as they are, but manually duplicate the remainder
-- of their behavior after I combined their common prefix.

-- Instead, you can add backtracking to a parser with the 'try' combinator.
-- 'try aa' is exactly like aa, except that if 'try aa' fails at any point, the
-- parser will back up to the point where aa started parsing so that the next
-- alternative can take over. A simpler way to combine aa and ab correcty is
aaOrab :: Parser (Char, Char)
aaOrab = try aa <|> ab

-- If you don't like the non-backtracking behavior of Parsec's <|> operator, you
-- can always build a 'try' into every use of <|> and just assume that
-- backtracking will always occur as needed. For example, you can just always
-- use the following operator instead of the underlying <|>.
parse1 <||> parse2 = try parse1 <|> parse2

-- The reason that Parsec uses the more complicated, non-backtracking, version
-- of <|> is for performance. 'try' has a cost, since checkpoints have to be
-- saved along with the corresponding portions of the input string from that
-- checkpoint. And no form of "garbage collection" is performed on the input
-- string to clear checkpoints that are no longer needed, so that every 'try'
-- will linger in memory until the parser completely finishes.  This can consume
-- much more memory in certain situations, so overusing try can lead to bad
-- performance.

