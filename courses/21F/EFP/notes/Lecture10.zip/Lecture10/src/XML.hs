module XML where

import Text.Parsec
import Text.Parsec.String

-- Because Parsec parsers go beyond context-free grammars (and so are much much
-- more expressive than regular expressions), they make it fairly painless to
-- express context-sensitive languages like XML. XML has openening and closing
-- tags (written as <name> and </name>, respectively, for any choice of name)
-- which are balanced like paraentheses and also have matching names. Balancing
-- opening and closing tags is not difficult. The challenge of XML is the
-- matching requirement, because the exact closing tag that should be expected
-- depends on whatever the name of the corresponding opening tag happened to be
-- earlier on in the textual input.

type Name = String

data XML = Text String  -- Some plain text
         | Node         -- A general XML node containing many children
           Name         -- The name of the node, in both the open and close tag
           [XML]        -- The children
  deriving Show

xml :: Parser XML
xml = text <|> node

text :: Parser XML
text = do t <- many1 (noneOf "<>&")
          return (Text t)

-- Here is the entire trick for implementing matching between open and close
-- tags. When parsing a new openTag, we *learn* the name of the tag from the
-- returned result of the parser. Then, when later parsing the closeTag (after
-- the many children have been parse) we can *check* that the name in the
-- closeTag is the same as the corresponding openTag that it balances with.
node :: Parser XML
node = do name <- try openTag
          spaces
          children <- xml `sepEndBy` spaces
          closeTag name
          return (Node name children)

-- To parse an openTag, parse a name in between two angle brackets, and return
-- that name so it can be used the corresponding closeTag.
openTag :: Parser Name
openTag = do char '<'
             n <- name
             char '>'
             return n

-- To parse a closeTag, parse a name in between "</" and ">", and check that the
-- name is *exactly* the same as the corresponding openTag.
closeTag :: Name -> Parser ()
closeTag name = do string "</"
                   string name
                   string ">"
                   return ()

-- A name is any sequence of one or more letters (a letter being some upper or
-- lower case alphabetic character, maybe including accents like é).
name :: Parser Name
name = many1 letter -- <?> "tag name: one or more alphabetic letters"
