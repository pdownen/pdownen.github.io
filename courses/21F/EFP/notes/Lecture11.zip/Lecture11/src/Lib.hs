module Lib where

-- Haskell uses "lazy evaluation." This means that the arguments to functions
-- and constructors are only ever evaluated (meaning, simplified down to a basic
-- value like a specific number for Integers or True or False for Bools) when
-- they are "needed." Lazy evaluation can be seen as an optimization (since
-- there are no side effects, there is no point in evaluating a function call if
-- the result is never used). But one extra consequence of lazy evaluation is
-- data structures like lists can be *infinite*, and go on forever. For example,
-- the range [1..10] includes just the numbers from 1 to 10
--
--     [1..10] = [1,2,3,4,5,6,7,8,9,10]
--
-- but the range [1..] which does not specify an upper bounds includes *all* the
-- numbers equal to or greater than 1
--
--     [1..] = [1,2,3,4,5,6,7,8,9,10,11,12,...

-- 'myTake' is the same as 'take' function from Prelude.
--
--     myTake 5 [1,2,3,4,5,6,7,... = [1,2,3,4,5]
myTake :: Int -> [a] -> [a]
myTake _ []     = []
myTake 0 _      = []
myTake n (x:xs) = x : (myTake (n-1) xs)
-- myTake will cut off a list to a given length. This works on both finite *and*
-- infinite lists.
--
--     myTake 10 [1..] = [1..10]

-- The interesting consequence of this fact is that you can modify infinite data
-- structures like lists first *before* you cut them down into the part you
-- actually need.  For example, you can filter an infinite list to throw out
-- elements you don't need before deciding how many you want: since the filter
-- applies first, you still get the desired number of elements at the
-- end. Compare the difference with the following to combinations of taking and
-- filtering:
--
--    myTake 5 (filter even [1..]) = [2,4,6,8,10]
--    filter even (myTake 5 [1..]) = [2,4]

-- Here are some basic functions for generating infinite lists. Note that they
-- are just recursive functions; nothing special needs to be done to activate
-- laziness. When you call these functions, you don't see an infinite
-- loop. Instead, you only see the amount of their returned list that you
-- actually use.

-- The same as 'repeat' from Prelude
--
--     myRepeat x = [x, x, x, x, x, x, ...
myRepeat :: a -> [a]
myRepeat x = x : myRepeat x

-- The same as 'cycle' from Prelude
--
--     myCycle [1,2,3] = [1,2,3,1,2,3,1,2,3,...
myCycle :: [a] -> [a]
myCycle xs = xs ++ myCycle xs

-- Another definition, using the local looping 'go' function
myCycle' xs = go xs
  where go [] = go xs
        go (x:xs') = x : go xs'

-- The example expression from the very first assignment:
--
--     let motor sounds = sounds "Vroom! " in motor cycle

motor :: (String -> a) -> a    -- The most general type of motor
-- motor :: (String -> String) -> String    -- A more specific type
motor sounds = sounds "Vroom! "

rumble :: String
rumble = motor cycle

{-
You can use equational reasoning to simplify 'rumble' and figure out exactly
what it is doing.

rumble
=
motor cycle
=
cycle "Vroom! "
=
cycle ['V','r','o','o','m','!',' ']
=
['V','r','o','o','m','!',' ','V','r','o','o','m','!',' ',...
-}

-- Laziness is not something special about lists. EVERY data type in Haskell is
-- lazily evaluated, including custom data types you define for yourself.

-- For example, binary trees are lazily evaluated.
data Tree a = Leaf | Branch (Tree a) a (Tree a)
  deriving Show

-- We can grow a tree without bound. 
grow :: (a -> a) -> (a -> a) -> a -> Tree a
grow f g x = Branch (grow f g (f x)) x (grow f g (g x))

-- 'prune' cuts off a given tree to a specified height, throwing away all
-- sub-trees below that depth. 'prune' is the analogous function as 'take' but
-- for binary trees instead of sequential lists.
prune :: Integer -> Tree a -> Tree a
prune 0 _              = Leaf
prune _ Leaf           = Leaf
prune n (Branch t x u) = Branch (prune (n-1) t) x (prune (n-1) u)

-- Now, recall the 'growTree' function from lecture 7, that is like 'grow', but
-- it stops after a given depth is reached.
growTree :: (a -> a) -> (a -> a) -> a -> Int -> Tree a
growTree f g x 0 = Leaf
growTree f g x n = Branch
                   (growTree f g (f x) (n-1))
                   x
                   (growTree f g (g x) (n-1))
-- growTree is equal to a composition of the above grow and prune functions.
--
--     growTree f g x n = prune n (grow f g x)
