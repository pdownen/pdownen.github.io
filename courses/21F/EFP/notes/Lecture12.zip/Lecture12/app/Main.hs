module Main where

import SyncOut

import Control.Concurrent

-- A simple control-flow function: repeatM n a repeats the action a n times. All
-- results returned by a are discarded.
repeatM 0 act = return ()
repeatM n act = do
  act
  repeatM (n-1) act

-- The sequential combination of two actions. First repeatedly print "Hello" 100
-- times. Then once that's done, repeatedly print "Goodbye" 100 times.
sync = do
  repeatM 100 $ putStrLn "Hello"
  repeatM 100 $ putStrLn "Goodbye"
  return ()

-- The concurrent combination of two actions, using the forkIO function from
-- Control.Concurrent
--
--     forkIO :: IO () -> IO ThreadId
--
-- forkIO takes an IO action as an input, and then spawns another thread that
-- runs separately from this one. This allows for you to observe two different
-- actions woven together. The choice of order for interleaving multiple
-- threads, called the schedule for choosing when a step from one action or the
-- other takes place first, is managed by the run-time system and is effectively
-- random. The ThreadId value returned by forkIO is a handle to the thread that
-- forkIO just spawned, letting you interact with the thread later using other
-- functions from Control.Concurrent.
async = do
  forkIO $ repeatM 100 $ putStrLn "Hello"
  repeatM 100 $ putStrLn "Goodbye"
  return ()
-- Oh no! This operation causes a garbled mess all over the console. What
-- happened?

-- The putStrLn operation is is not *atomic*, meaning that it is made up of
-- smaller steps, and can be interrupted in the middle of its execution by
-- another thread. putStrLn is built on top of a more basic primitive operation
-- putChar
--
--     putStrLn :: String -> IO ()
--     putChar  :: Char -> IO ()
--
-- so only printing one character at a time is an atomic operation. That means
-- that when two threads are trying to print a single line to the console at
-- once, the individual characters from their lines can get mixed up, as small
-- batches of putChar actions are run back and forth from both threads. This
-- class of bugs, where multiple threads are incorrectly interrupting each other
-- for access to a shared resource, is called a *race condition*.

-- Instead of mixing up all the output, what we *really* want is to have an
-- atomic "print an entire line to the console at once" operation. I've defined
-- some helper functions in the module SyncOut that can do just that. Instead of
-- putStrLn, SyncOut provides the function
--
--     say :: String -> IO ()
--
-- that queues up a message to write to the console, but does not perform the
-- write immediately. Then at any point, you can call
--
--     flushStdout :: IO ()
--
-- which will write all the queued messaged to the console at once.

-- Using these threadsafe operations from SyncOut, we have following version of
-- the concurrent Hello-Goodbye action that fixes the race condition, so that
-- each line of output is written to the console atomically.
async' = do
  forkIO $ repeatM 100 $ say "Hello"
  forkIO $ repeatM 100 $ say "Goodbye"
  threadDelay 10
  flushStdout
  return ()
-- Note that the use of
--
--     threadDelay :: Int -> IO ()
--
-- ensures that the current thread is paused for *at least* the given number of
-- microseconds (but perhaps longer, due to the randomness of concurrent
-- scheduling discussed above). This is done to make sure that at least a few
-- "Hello" or "Goodbye" messages have been queued up before attempting to flush
-- the standard output.

main = async'
