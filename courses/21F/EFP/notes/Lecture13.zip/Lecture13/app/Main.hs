module Main where

-- The Santa Claus problem[1]:
--
--     Santa repeatedly sleeps until wakened by either all of his nine reindeer,
--     back from their holidays, or by a group of three of his ten elves. If
--     awakened by the reindeer, he harnesses each of them to his sleigh,
--     delivers toys with them and finally unharnesses them (allowing them to go
--     off on holiday). If awakened by a group of elves, he shows each of the
--     group into his study, consults with them on toy R&D and finally shows
--     them each out (allowing them to go back to work). Santa should give
--     priority to the reindeer in the case that there is both a group of elves
--     and a group of reindeer waiting.
--
-- [1] https://www.schoolofhaskell.com/school/advanced-haskell/beautiful-concurrency/4-the-santa-claus-problem


import SyncOut
import Passage

import Data.List (init, last, intercalate)
import Data.Traversable (for)
import Control.Applicative ((<|>))
import Control.Monad (forever)
import Control.Concurrent (threadDelay, forkIO, killThread)
import Control.Concurrent.STM (STM, atomically)
import System.Random (randomRIO)

-- Both elves and reindeer are represented by a unique number distinguishing
-- them from one another.
data Elf      = Elf      Int deriving Show
data Reindeer = Reindeer Int deriving Show


-- Wait for a random number of seconds within the given range.
wait :: Int -> Int -> IO ()
wait n m = do
  delay <- randomRIO (n*10^6, m*10^6)
  threadDelay delay

-- Say some additional side message for more diagnostic information.
aside :: Show a => a -> String -> IO ()
aside actor message = say $ "    " ++ show actor ++ " " ++ message
-- aside _ _ = return ()
-- Use the above commented-out definition of 'aside' for a less noisy output.

-- An elf waits to pass into the study, meets with Santa, and then passes back
-- into the workshop once dismissed.
elf :: Elf -> Passage Elf -> IO ()
elf me study = forever $ do
  wait 1 20
  aside me "is ready for toy R&D"
  workshop <- pass study me
  say $ show me ++ ": meets with Santa in the study"
  pass workshop me
  aside me "runs off to work on more toys"
  wait 5 20

-- A reindeer waits to be tied up to the sled, pulls Santa to deliver toys, and
-- then waits to be unharnessed from the sled to go on holiday.
reindeer :: Reindeer -> Passage Reindeer -> IO ()
reindeer me sled = forever $ do
  wait 1 20
  aside me "is ready to go for a ride"
  harness <- pass sled me
  say $ show me ++ ": pulls the sleigh"
  pass harness me
  aside me "scampers off to play reindeer games"
  wait 10 30

-- Santa waits for either all the reindeer to gather at the sled, or a group of
-- elves to wait by his study (in that order of preference). When all
-- participants of either group is ready, Santa then acts with them, delivering
-- toys with the reindeer, or meeting with the elves in his study.
santa :: Passage Reindeer -> Passage Elf -> IO ()
santa sled study = forever $ do
  group <- atomically $
           (do (rs, harness) <- open sled
               sayT $ replicate 40 '<'
               sayT $ "Santa ties " ++ listed rs ++ " to the sled"
               return (Left harness))
           <|>
           (do (es, workshop) <- open study
               sayT $ replicate 40 '<'
               sayT $ "Santa: takes " ++ listed es ++ " to his study"
               return (Right workshop))
  case group of
    Left harness -> do
      say $ "Santa: \"HO HO HO! Merry Christmas!\""
      wait 2 6
      say $ "Santa: delivers toys to good little children"
      wait 5 10
      (rs, _) <- atomically $ open harness
      say $ "Santa: unharnesses " ++ listed rs
      say $ replicate 40 '>'
    Right workshop -> do
      wait 1 3
      say $ "Santa: plans out toy production"
      wait 1 3
      (es, _) <- atomically $ open workshop
      say $ "Santa: sends " ++ listed es ++ " to the workshop"
      say $ replicate 40 '>'

-- Display a list of (Showable) elements in English prose.
listed :: Show a => [a] -> String
listed []    = ""
listed [x]   = show x
listed [x,y] = show x ++ " and " ++ show y
listed xs    = intercalate ", " (beginning ++ ["and " ++ final])
  where final     = show (last xs)
        beginning = map show (init xs)

-- Run a simulation of the North Pole.
main :: IO ()
main = do
  let r = 9    -- total number of reindeer
  let e = 10   -- total number of elves
  let s = 3    -- number of elves allowed in Santa's study at one time

  -- Initialize passages and output process
  sled  <- atomically $ newPassage r
  study <- atomically $ newPassage s
  outp  <- processStdout

  -- Start up each reindeer
  reindeer <- for [1..r] $ \i -> do
    forkIO $ reindeer (Reindeer i) sled

  -- Start up each elf
  elves <- for [1..e] $ \i -> do
    forkIO $ elf (Elf i) study

  -- Start up Santa Clause
  clause <- forkIO $ santa sled study

  -- Wait for user to press enter to end the simulation
  getLine

  -- Shut down all processes
  killThread clause
  for reindeer killThread
  for elves killThread
  waitForStdout
  killThread outp
