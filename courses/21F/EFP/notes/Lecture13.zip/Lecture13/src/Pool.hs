module Pool where

-- Usually, concurrency frameworks/libraries come with many different primitive
-- mechanisms for organizing coordination, synchronization, and communication
-- between processes. Examples include locks, semaphores, channels, and
-- queues. To solve a particular concurrent problem, you need to select which
-- primitive mechanisms apply to your situation and let you write a program
-- without deadlocks or race conditions.

-- With Software Transactional Memory (STM), the only essential primitive
-- mechanisms you need are:
--
--   * Transactional variables (TVars) which have the same interface as regular
--     IO references (IORefs), but live in STM instead,
--
--   * The 'atomically' operation for converting an STM action into an "atomic"
--     real IO action, and
--
--   * The STM instances of the effect type class interfaces (Functor,
--     Applicative, Monad, and Alternative).
--
-- All the other concurrency mechanisms in the STM library can (and are) built
-- on top of these. For example, 'TMVar a' (transactional mutex variable) is
-- just a 'TVar (Maybe a)', and a TQueue is (essentially) a TVar containing a
-- purely functional FIFO list.  The advantage of having simple, but composable,
-- primitives is that you can build your own custom concurrency mechanisms if
-- none of the standard ones nicely fit your problem. This module looks at
-- building a specialized concurrency mechanism called a Pool.

import Control.Concurrent.STM (STM, check)
import Control.Concurrent.STM.TVar
  (TVar, newTVar, newTVarIO, writeTVar, readTVar)

-- A 'Pool a' is a gathering of 'a's up to a fixed total size. A Pool is like an
-- unordered version of a bounded Queue, where everything in the pool must be
-- emptied out at once it is full in no particular order.

data Pool a
  = Pool
    Int         -- Total capacity of the pool
    (TVar Int)  -- Number of 'a's currently in the pool
    (TVar [a])  -- The pool of 'a's

-- Create a new Pool of the given capacity.
newPool :: Int -> STM (Pool a)
newPool c = do
  num <- newTVar 0
  elem <- newTVar []
  return (Pool c num elem)

-- The total capacity of a pool.
poolSize :: Pool a -> Int
poolSize (Pool c _ _) = c

-- Enter a Pool with room remaining. enterPool blocks if the Pool is full (that
-- is, at capacity).
enterPool :: Pool a -> a -> STM ()
enterPool (Pool c num elems) x = do
  n <- readTVar num
  check (n < c)
  xs <- readTVar elems
  writeTVar num (n+1)
  writeTVar elems (x:xs)
  return ()

{-
check True  = return ()
check False = retry
-}

-- Empty the entire contents of a completely full Pool all at once. emptyPool
-- blocks if the Pool is not full (there is still room to add more elements).
emptyPool :: Pool a -> STM [a]
emptyPool (Pool c num elems) = do
  n <- readTVar num
  check (n == c)
  xs <- readTVar elems
  writeTVar elems []
  writeTVar num 0
  return xs
