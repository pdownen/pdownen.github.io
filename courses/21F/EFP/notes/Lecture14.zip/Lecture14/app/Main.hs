module Main where

import System.Environment (getArgs)
import Control.Parallel (par)
import Control.Parallel.Strategies (Strategy, parMap, parList, rseq)

------------------------------
--- Parallelism Primitives ---
------------------------------

-- Haskell employs "lazy evaluation," which means that an expression is only
-- evaluated only when needed, and only as far as required for its context. For
-- example, the function which ignores its first argument and returns its second
-- argument
ignore :: a -> b -> b
ignore x y = y
-- will never evaluate its first argument because it's not needed. This can be
-- seen when ignore is given an expression which causes an error, like division
-- by zero (1 `div` 0) or using the error-raising function (error "boom" or
-- undefined).
--
--     ignore 1 2 = 2
--     ignore (error "boom") = 2

-- In contrast, the special function `seq` (short for "sequence")
-- 
--     seq :: a -> b -> b
--
-- also takes two arguments and returns the second, but evaluates the first
-- argument anyway even though it's not needed to determine the result. So
--
--     seq 1 2 = 2
--     seq (error "boom") 2 = error "boom"
--
-- seq is used in practice as an optimization trick to reduce the amount of
-- memory used by forcing evaluation of expressions to occur earlier than
-- necessary. For example, an Int value takes up a fixed, small amount of space
-- in memory, but in general an unevaluated Int expression could take up a very
-- large amount of space.

-- Like seq, there is another similar special function from Control.Parallel
-- called `par` (short for "parallel")
--
--     par :: a -> b -> b
--
-- which also returns the value of the second argument. From the outside, par
-- looks identical to ignore, where the second argument is returned no matter
-- what the first argument is:
--
--     par 1 2 = 2
--     par (error "boom") 2 = 2
--
-- So par can be completely ignored for the purpose of determining what the
-- result will be. But unlike 'ignore', the first argument to par may be
-- evaluated *in parallel* with the evaluation of the second argument. This
-- parallel evaluation is not mandatory---the run-time system is free to ignore
-- evaluating the first argument if it is no longer necessary---so `par` serves
-- as an optimization hint to the compiler. The reason why so much flexibility
-- can be given to the implementation to determine when and whether to evaluate
-- the parallel expression without affecting the result is due to purity:
-- evaluating an expression of the type a cannot cause any side effects to
-- occur! So if the result of an expression is not used, then the only impact
-- its evaluation can have on a program is performance.

-- Both `seq` and `par` give us two different ways to compose a calculation
-- together: sequential and parallel. We can generalize sequential and parallel
-- composition over a whole list, evaluating each element of the list in
-- sequence or in parallel before returning the secondary argument.
seqs :: [a] -> b -> b
seqs [] y = y
seqs (x:xs) y = x `seq` seqs xs y

pars :: [a] -> b -> b
pars [] y = y
pars (x:xs) y = x `par` pars xs y
-- Note that `seq` and `par` are commonly used in infix form as above, since it
-- reads more naturally as a list of tasks written in order, such as:
--
--     x `par` y `par` x+y

-- To test the performance difference between sequential and parallel
-- composition, we need to come up with some busy work for the computer to do. A
-- simple way to waste time is to count down a (potentially large) number until
-- it reaches 0.
spin :: Integer -> a -> a
spin 0 x = x
spin n x = spin (n-1) x

-- Now, we can test the difference between running a large list of busy work in
-- sequence versus in parallel. By changing the parameters n (the number of
-- tasks) and m (the size of each individual task), you can see how sequential
-- and parallel composition compare with one another.
runSeq n m = do
  let tasks = replicate n (spin m ())
  putStrLn (seqs tasks "Done")
  return ()

runPar n m = do
  let tasks = replicate n (spin m ())
  putStrLn (pars tasks "Done")
  return ()

-- main = runSeq (10^6) (10^9)
-- main = runPar (10^6) (10^9)

----------------
--- N Queens ---
----------------

-- "8 Queens" is a classic puzzle based on the game of chess stated as follows:
-- how many ways can you place 8 queens on an 8-by-8 chess board such that none
-- of the queens threatens (that is, can attack in one move) any other
-- queen. This puzzle is perfect for writing algorithmic solution, since there
-- is a very large search space with an easy-to-check criteria for potential
-- solutions. In computer science, "8 Queens" is often generalized to "n Queens"
-- by placing n queens on an n-by-n chess board in the same manner.

-- To solve the n Queens problem, we need to represent a potential solution: a
-- chess board containing only queens. Due to the rules of chess, we can
-- simplify some of the details in the representation. Since the queens are not
-- allowed to threaten one another, there can be at most one queen in each row
-- and each column of the board. Furthermore, since we are limited to a board
-- with the same number of rows and columns as queens, it means that each row
-- and column must have *exactly one* queen in it to be a valid
-- solution. Therefore, we can represent the chess board as a list of rows
-- containing a number specifying the column position of the queen in that row.
type QueenBoard = [Int]

-- The first part of the puzzle is test a potential placement of a queen on the
-- next row of a partially-completed board. Given that we want to attempt
-- placing a queen at the given column q of the next row of the board, the
-- function 'safe q board' will return True when that newly-placed queen is safe
-- from attacks by all the other queens already on the board.
safe :: Int -> QueenBoard -> Bool
safe queen board =
  and [ queen /= attack
      | (dist, queen') <- zip [1..] board,
        attack <- [queen' - dist, queen', queen' + dist] ]

-- The next part of the puzzle is to take a partially completed board and try
-- all possible placements of the next queen. Given that the board has n columns
-- to work with, 'children n board' will return a list of all the possible
-- placements of a queen in the next available row.
children :: Int -> QueenBoard -> [QueenBoard]
children n board = [ (queen:board) | queen <- [1..n], safe queen board ]

-- The final part of the puzzle is to place all the necessary queens on the
-- chess board. If we want to place n queens in total, and have r queens
-- remaining to place on the given board, then 'subtree n r board' will return
-- all possible placements of the remaining r queens onto the partially
-- completed board.
subtree :: Int -> Int -> QueenBoard -> [QueenBoard]
subtree n 0 board = [board]
subtree n r board = concat
                  $ map (subtree n (r-1))
                  $ children n board

-- The solution to the n Queen problem for a particular choice of n is defined
-- by the function nqueen n, which is shorthand for computing the subtree of
-- solutions for n total queens beginning with an empty board and n queens
-- remaining to be placed on the board.
nqueen :: Int -> [QueenBoard]
nqueen n = subtree n n []

-- You can test the above nqueens solver by generating all possible solutions
-- for a particular choice of n (passed on the command line as a parameter to
-- the program) and then counting the number of different solutions.
countSolutions solver = do
  [num] <- getArgs
  let n = read num
  let soln = solver n
  putStrLn $ show (length soln) ++ " solutions for " ++ show n ++ " queens"

-- main = countSolutions nqueen

-- The n Queens solver above evaluates the possible solution sequentially, which
-- is the default mode of evaluation for all Haskell programs. Luckily, the n
-- Queens problem is easy to calculate in parallel, since there are many
-- intermediate subproblems that do not depend on each other. Using some of the
-- helper Strategies from Control.Parallel.Strategies, which are built on top of
-- the `par` function above, the difference between the parallel and the
-- sequential solvers is that the parallel solver evaluates the list of
-- subproblems for a step in parallel using 'parMap' instead of 'map'.
subtreePar :: Int -> Int -> QueenBoard -> [QueenBoard]
subtreePar n 0 board = [board]
subtreePar n r board = concat
                     $ parMap queenStrat (subtreePar n (r-1))
                     $ children n board
-- 'parMap' gives the exact same result as 'map' for any given function. The
-- only difference is that each answer in the resulting list is evaluated
-- ahead-of-time in parallel as the whole list of answers is returned. That way,
-- when you go and inspect the list later on in the future, chances are that
-- many of the individual elements have already been simplified down for
-- you. This is in contrast with ordinary 'map' which instead will return a list
-- of delayed answers, each of which are only ever evaluated when you look at it
-- for the first time.

-- The one wrinkle with this story is that laziness (delaying evaluation until
-- the result is needed) is both a boon and a bane to this style of pure
-- parallel evaluation. On the one hand, everything is already a "promise" of an
-- answer in the future which *must* be computed when the answer needs to be
-- known, but *could* be evaluated in advance anyway. On the other hand, the
-- notion of "evaluate in advance" is probably much, much weaker than what you
-- were intending. That's why 'parMap' takes one extra parameter, which defines
-- a Strategy for how far to evaluate each element of the resulting list before
-- stopping.

-- For subtreePar above, the default behavior of evaluating a [QueenBoard] in
-- advance will only go so far as to see if the list of QueenBoards is empty (no
-- solutions []) or is non-empty (some solutions board:boards). That's not
-- enough preemptive evaluation to be helpful! Instead, what is really intended
-- is to completely evaluate the [QueenBoard] until we see the entire list of
-- list of Ints. This strategy for preemptive evaluation is described by the
-- following queenStrat definition, which uses the basic polymorphic 'rseq'
-- Strategy for Ints (which means to just evaluate the Int) which is extended to
-- lists of lists using the 'parList :: Strategy a -> Strategy [a]' function.
queenStrat :: Strategy [QueenBoard]
queenStrat = parList (parList rseq)

-- Having made the above subtree solver parallel, making the overall n Queen
-- solver parallel is just a matter of using subtreePar instead of subtree.
nqueenPar n = subtreePar n n []

-- Now, you can test the difference between parallel and sequential evaluation
-- on a larger problem by comparing nqueen with nqueenPar for different ns.
main = countSolutions nqueenPar
