# Changelog for Lecture3

## Unreleased changes
