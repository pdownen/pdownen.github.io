# Lecture3
