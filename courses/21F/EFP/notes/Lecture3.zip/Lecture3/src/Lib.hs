module Lib where

-- getLet :: IO String

-- The type of getLine is IO String because it will need to perform some IO
-- side-effects (interacting with the user via the console) to return its String
-- result. In most languages, getLine would have a function type like () ->
-- String, since all functions might cause side-effects to happen, but in
-- Haskell a function () -> String means a function that *always* returns the
-- same string when given the boring unit value () as an argument. Instead, the
-- ability to perform an action while attempting to return a value of type 'a'
-- is written 'IO a'. In Haskell, the when effects might happen is notated in
-- the type.

theLine :: IO String
theLine = getLine
-- theLine is an *alias* for the getLine IO action. This binding does not mean
-- to get a line *now*.

{-
getTwoLines = let first = getLine
                  second = getLine
              in (first, second)
-}
-- This *doesn't* get two lines. It's a pair of two actions, both of which will
-- happen to get a line when run. The type of this pair is
--
--     (IO String, IO String).

-- To chain together several actions, use a 'do' expression.
getTwoLines :: IO (String, String)
getTwoLines = do first <- getLine
                 second <- getLine
                 return (first, second)
-- The first kind of 'do' statement is the '<-' statement (pronounced "bind").
-- It means to evaluate the expression and then run the IO action to the right,
-- bind the result of the action to the variable on the left. The 'return' means
-- just return this value, without doing anything else (i.e., don't perform any
-- side-effects).

putTwoLines :: String -> String -> IO ()
putTwoLines first second = do
  putStrLn first
  putStrLn second
-- The second kind of 'do' statement is just an IO action itself. This means the
-- action should just run for the side-effects, and the result is discarded.

-- Prompt a user for input by first displaying a question and then waiting for
-- their answer.
prompt :: String -> IO String
prompt question = do putStrLn question
                     getLine
-- The result of the *last* line of a 'do' expression is the result of the whole
-- expression. A final 'return' is not necessary when you just want to return
-- the result of some action, like getLine, as-is.

-- You can chain together your own defined IO actions with 'do'. In other words,
-- 'do' composes together any number of nested IO actions without limit.

-- Greet the user by first asking for their name, and then saying hello.
greet :: IO ()
greet = do
  name <- prompt "Who is this?"
  let greeting = "Hello, " ++ name ++ "!"
  putStrLn greeting
-- The third, and last, form of statement in a 'do' expression is a
-- 'let'. Unlike an ordinary 'let' expression, this one-line 'let' doesn't have
-- a corresponding 'in'. That's because the scope of the variable 'greeting' is
-- the remainder of the 'do' expression.

-- A 'let' statement in a 'do' expression is syntactic sugar for a normal 'let'
-- expression:
--
--     greet = do
--       name <- prompt "Who is this?"
--       let greeting = "Hello, " ++ name ++ "!" in do putStrLn greeting

-- There's a lot of syntactic sugar like this in Haskell. On the one hand, there
-- is a high amount of redundancy (many different syntactic forms for expressing
-- the same thing). On the other hand, different styles of sugar are sweeter in
-- different contexts (like declarations vs expressions). The austere version of
-- Haskell with all the redundancy and sugar removed lets you write the same
-- programs at the end of the day, but it is not nearly as nice to read and
-- write!!

-- Question: What does this IO action do? Does it return 1 or 2?
mystery :: IO Int
mystery = do
  return 1
  return 2
-- 'return' is a function, *not* a control statement. Breaking it down by the
-- rules above:
--
--   * The first statement means to return the value 1 without performing any
--     side-effects. Since this is a single action in the middle of the 'do'
--     expression, its return value 1 is ignored, and there are no side-effects
--     to perform, so it is the same as doing nothing.
--
--   * The second statement means to return the value 2 without any
--     side-effects. Since this is the final statement of the 'do' expression,
--     its return value 2 becomes the return value for the whole 'do'
--     expression.

-- Note the following two consequences of this fact:
--
--   * 'return' is *not* special. It does not need to occur at the end of a
--     'do'.
--
--   * The final statement of a 'do' *must* be a stand-alone action to be
--     performed. It does not have to be a 'return', but it *cannot* be a bind
--     or a let.

-- Another mystery. What does it do?
mystery' :: IO Int
mystery' = do
  x <- return 6
  return (x+1)
-- Remember, 'return' is an action that returns its given value. A bind
-- statement runs the action on the right and binds the returned value to the
-- variable on the left. Together this means that the first line of the 'do'
-- says to bind 6 to x. Therefore, the final result of the 'do' is to return x+1
-- with x = 6, i.e., return the value 6+1 = 7.

-- IO a actions are first-class values. You can define your own "control
-- structures" by defining ordinary functions that take IO actions as
-- parameters.

-- For example, 'forever' runs the given IO action forever.
forever :: IO a -> IO b
forever action = do action
                    forever action
-- 'forever action' is the same as an infinite do:
--
--     do action
--        action
--        action
--        ...

-- 'repeatUntilTrue' is another custom "control structure". It will repeatedly
-- run the given action until it returns True.
repeatUntilTrue :: IO Bool -> IO ()
repeatUntilTrue action = do
  x <- action
  if x
    then return ()
    else repeatUntilTrue action
-- This function uses an 'if-then-else' expression, which has the normal meaning
-- of 'if'; it tests the boolean after the 'if', returning the expression after
-- the 'then' if it was true and the expression after the 'else' if it was
-- false. Like 'case', 'if' is useful in the context of a 'do' because it is an
-- expression.

-- Note that Bool is a normal data type (you could define it yourself), so you
-- can do a 'case' on a Bool, which is exactly the same as an 'if'
-- expression. You never *need* 'if', you could always use 'case' instead, but
-- an 'if' might look a little nicer.
