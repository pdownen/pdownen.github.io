module RiskyBank where

import SyncOut

import Data.IORef
import Control.Concurrent
import Control.Concurrent.MVar
import Control.Monad (forever)
import System.Random (randomRIO)
import System.IO.Unsafe (unsafePerformIO)

-- You can represent a mutable variable or a mutable field of a data type (whose
-- value can change over time) with a reference. To help keep functional code
-- side-effect free, the fact that a value is a reference is always made
-- explicit in the type. The reference to a value (that is, the address to its
-- position in memory) appears constant and never changes, but the contents of
-- that reference might change over time. So references themselves can be passed
-- around without involving side-effects, but the read/write operations on a
-- reference are side-effectful.

-- The basic reference type in Haskell is IORef, found in the Data.IORef
-- module. The three most important operations involving IORefs are the
-- allocation of a new reference (newIORef), reading the current value of an
-- IORef (readIORef), and writing a new value to the reference (writeIORef),
-- which have the following types:
--
--     newIORef   :: a -> IO (IORef a)
--     readIORef  :: IORef a -> IO a
--     writeIORef :: IORef a -> a -> IO ()
--
-- Note that the use of IO in the type of the returned value of these three
-- operations signifies that each one involves some IO effect in order to
-- run. Also notice that the readIORef and writeIORef are similar to the get and
-- put operations of State from previous lectures, but they take an additional
-- IORef a parameter. That's because, unlike simple State which has exactly one
-- mutable value that changes over time, there can many references at once so
-- you need to specify which one you want to read or write.

-- With IORefs, you can model a basic bank account which has a Name for the
-- account (which does not change over time) as well as a Balance (which does
-- change frequently).
type Balance = Integer
type Name    = String
data Account = Acct Name (IORef Balance)

-- You can access both fields of the Account data type as normal, without
-- involving IO side effects...
name :: Account -> Name
name (Acct n _) = n

balance :: Account -> IORef Balance
balance (Acct _ b) = b

-- ... however, creating a new account now requires that you perform some IO
-- action in order to allocate a new updatable reference to hold the account's
-- balance.
newAccount :: Name -> Balance -> IO Account
newAccount n b = do
  ref <- newIORef b
  return (Acct n ref)

-- Likewise, printing out a representation of the account also requires the use
-- of IO, because reading the current balance of the account is an IO
-- action. This is not a pure, effect-free operation because the order in which
-- reading happens with respect to writes matters.
printAccount :: Account -> IO ()
printAccount (Acct n ref) = do
  b <- readIORef ref
  say $ "Name: " ++ n ++ ", Balance: $" ++ show b

printAccountNow acct = do
  printAccount acct
  flushStdout

-- The downside of using IORefs is that you can't easily make a top-level
-- constant for a person's account. That's because there is no function of type
-- IO a -> a, saying that a side-effectful IO a action is equivalent to a pure
-- effect-free value of type a... Except for unsafePerformIO...

-- unsafePerformIO is, in general, a rather dangerous action for two
-- reasons. One, it breaks the promise that the Haskell type system enforces
-- about side effects, where a function of type Int -> Int should not cause any
-- side effects but it might be hidden by unsafePerformIO. Two, due to laziness
-- it can be difficult to predict exactly when a particular expression will be
-- evaluated on-demand, and so it can be hard to figure out when an unsafely
-- performed IO action will eventually be run. Both of these problems can easily
-- cause serious errors which are very difficult to track down.

-- But in practice, there can occasionally be situations where unsafePerformIO
-- is both useful and doesn't cause one of the two problems above. A really
-- simple example is unsafePerformIO (return 5). While an action of type IO Int
-- might cause some noticeable side effect, the specific action 'return 5' does
-- not, and so
--
--      unsafePerformIO (return 5) = 5
--
-- But putStrLn "Boo!" does cause a very noticeable side effect, and
-- unsafePerformIO (putStrLn "Boo!") can create bizarre behavior in your
-- program. So if you have a specific IO action that you *know* does not cause
-- any noticeable side effects that could be observed by a user or disturb some
-- other corner of your program, then unsafePerformIO may be safe in that
-- particular application.

-- In this particular application, it would be useful to just have two Accounts
-- to test with. Since the action of creating a new reference cannot be observed
-- within the program or by the user (the only thing that happens is that a
-- small piece of memory becomes reserved for that reference), the use of
-- unsafePerformIO is okay here.
jack, jill :: Account
jack = unsafePerformIO (newAccount "Jack" 1000)
jill = unsafePerformIO (newAccount "Jill" 2000)
-- In the wild, you may sometime see this pattern of using unsafePerformIO to
-- allocate a resource and assign it to a name. This is especially useful for
-- writing a library with some standard resources that are commonly used and
-- shared among several operations (see SyncOut). The lesson is that
-- unsafePerformIO can be useful... but be very careful when you use it.

-- To continue modeling the bank, the first operation is to deposit some amount
-- of money into a given account. Here, I'm printing out some extra diagnostic
-- messages (via 'say') so that you can see what's going on interactively while
-- some transactions are running. Alternatively, you might re-direct the output
-- to a logging file to perform post-mortem diagnostics of bank transactions in
-- case something goes wrong. The primary steps of a deposit are:
--
--   1. Read the current value of the account balance (old)
--   2. Write a new value to the account balance (old + amount)
deposit :: Integer -> Account -> IO ()
deposit amount acct = do
  old <- readIORef (balance acct)
  say $ "Depositing $" ++ show amount ++ " to " ++ name acct
  writeIORef (balance acct) (old + amount)
  new <- readIORef (balance acct)
  say $
    name acct ++ "'s deposit completed (" ++
    show old ++ " + " ++ show amount ++ " = " ++ show new ++ ")"

-- Here is how to withdraw some money into a bank account. It is only slightly
-- more complex than a deposit, because the account might not have sufficient
-- funds. The primary steps of a withdrawal are:
--
--   1. Read the current value of the account balance (old)
--   2. Check whether or not the account balance contains less than the
--      requested amount (old < amount)
--      a. If the balance is smaller then the amount, the withdrawal fails
--         (return False)
--      b. Otherwise, the balance is updated (old - amount) and the withdrawal
--         succeeds (return True)
withdraw :: Integer -> Account -> IO Bool
withdraw amount acct = do
  old <- readIORef (balance acct)
  if old < amount
    then do
      say $
        "Can't withdraw $" ++ show amount ++ " from " ++ name acct ++
        " (insufficient funds)"
      return False
    else do
      say $ "Withdrawing $" ++ show amount ++ " from " ++ name acct
      writeIORef (balance acct) (old - amount)
      new <- readIORef (balance acct)
      say $
        name acct ++ "'s withdrawal completed (" ++
        show old ++ " - " ++ show amount ++ " = " ++ show new ++ ")"
      return True

-- Transferring an amount of money from one account to another is just a matter
-- of withdrawing the amount of money from the first account, and then
-- depositing the same amount of money to the second account (but only if the
-- withdrawal succeeded!).
transfer :: Integer -> Account -> Account -> IO Bool
transfer amount from to = do
  say $
    "Transferring $" ++ show amount ++
    " from " ++ name from ++
    " to " ++ name to
  sufficient <- withdraw amount from
  if sufficient
    then do deposit amount to; return True
    else return False

-- Here is a test of the bank account system, which models a silly scenario
-- where two accounts are repeatedly sending the same amount of money back and
-- forth concurrently.
backAndForth :: Integer -> Account -> Account -> IO ()
backAndForth amount a b = do
  outp <- processStdout
  aToB <- forkIO $ forever $ do
    transfer amount a b
    delay
  bToA <- forkIO $ forever $ do
    transfer amount b a
    delay
  _ <- getLine -- Wait for user input to press any key, stopping the simulation
  killThread aToB
  killThread bToA
  waitForStdout
  killThread outp
  return ()

delay :: IO ()
delay = do
  wait <- randomRIO (10^3, 10^6)
  threadDelay wait

-- A more extreme edge case for stress testing the bank account system. Have two
-- threads concurrently draining account a and transferring all the money into
-- account b as fast as possible. In order to synchronize both threads, funnel2
-- uses a pair of MVars. MVars are similar to IORefs, except that the MVar might
-- be *empty*, and instead of reading and writing, you take the value out of an
-- MVar (leaving it empty) and put a new value into an empty MVar. The main
-- operations on MVars are
--
--     newEmptyMVar :: IO (MVar a)
--     takeMVar     :: MVar a -> IO a
--     putMVar      :: MVar a -> a -> IO ()
--
-- Intuitively, you can think of an 'MVar apple' as a box that can contain
-- exactly one apple, and to take the apple out of it you have to wait until it
-- has one, or put an apple into it you have to wait until it is empty. The
-- synchronization is performed by creating two empty MVars (one for each
-- thread), and after spawning both threads, the main thread wait for them to
-- finish by trying to take the contents of both MVars. When a thread is done,
-- it puts a token value into its MVar. That way, the main thread only finishes
-- when the two spawned threads are done.
funnel2 :: Integer -> Account -> Account -> IO ()
funnel2 amount a b = do
  done1 <- newEmptyMVar
  done2 <- newEmptyMVar
  forkIO $ do
    repeatUntilFalse (transfer amount a b)
    putMVar done1 ()
  forkIO $ do
    repeatUntilFalse (transfer amount a b)
    putMVar done2 ()
  takeMVar done1
  takeMVar done2
  flushStdout
  return ()

repeatUntilFalse :: IO Bool -> IO ()
repeatUntilFalse act = do
  b <- act
  if b
    then repeatUntilFalse act
    else return ()

-- But whats happening with funnel2?! You should expect that, if you funnel all
-- the money from jack to jill, then jack ends up with $0 and jill with $3000
-- ($2000 + $1000 = $3000). But instead, it's very likely that funneling the
-- money ends up with weird final amounts in the target account; sometimes more,
-- sometimes less than the sum total.

-- The reason for this is because the above bank account system suffers from a
-- race condition similar to the one seen with putStrLn. If you read the above
-- deposit and withdraw functions, they make perfect sense as sequential
-- operations. But there is an opportunity in both deposit and withdraw (albeit
-- a small one) that in between reading the old value and writing a new updated
-- value, some other thread may update the account. What happens in that case is
-- that the other thread's work is trampled over. The funnel2 function does
-- these withdrawals and deposits from the same accounts so quickly back to back
-- that it causes this edge case to happen, causing money to be lost into the
-- void or to spring forth into existence from nowhere. That's not a very good
-- banking system!
