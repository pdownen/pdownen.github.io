module SyncOut where

-- This module provides output primitives that are thread safe. Primarily, this
-- solves the problem that two putStrLn operations happening concurrently in
-- separate threads can interleave output. Every call to 'say' (the equivalent
-- to putStrLn) will output an entire line at once. To make sure that no race
-- conditions occur during printing, there *must* be exactly one active printer
-- for the entire program. This module provides two different types of printers:
-- interactive printers which process in another thread, and sequential printers
-- that flush all queued output before moving on.

import Control.Monad (forever, forM_)
import Control.Monad.STM (STM, atomically)
import Control.Concurrent (forkIO, threadDelay, ThreadId)
import Control.Concurrent.STM.TQueue
import System.IO.Unsafe (unsafePerformIO)

-- An output queue is modeled as a transactional (STM-style) queue of pending
-- outputs. Each output is a String, and represents a separate line of
-- output. Each output is printed on a separate line.
type OutputQ = TQueue String

--------------------------------------
--- Threadsafe, Queue-based Output ---
--------------------------------------

-- sayTo (and the corresponding sayIO) queues up the given message to the given
-- Output queue.
sayTo :: OutputQ -> String -> STM ()
sayTo out message = writeTQueue out message

sayIO :: OutputQ -> String -> IO ()
sayIO out message = atomically (sayTo out message)

-- processOutput takes an output queue and spawns a separate thread which prints
-- out all the messages seen on that queue. processOutput can be used to
-- interactively print output while the main thread is running, similar to
-- putStrLn, but each line is written atomically so long as there are no other
-- active printers.
processOutput :: OutputQ -> IO ThreadId
processOutput out = forkIO $ forever $ do
  message <- atomically (readTQueue out)
  putStrLn message
  return ()

-- flushOutput takes an output queue and prints out every message in it
-- sequentially, returning control back to the calling thread only when all
-- messages are printed.
flushOutput :: OutputQ -> IO ()
flushOutput out = do
  everything <- atomically (flushTQueue out)
  case everything of
    [] -> return ()
    _  -> do forM_ everything putStrLn
             flushOutput out

-- waitForOutput takes an output queue and waits until the queue is empty, only
-- returning control back to the calling thread only once the given queue is
-- empty. waitForOutput is useful when you have called processOutput, so that
-- messages are being printed out, and you want to wait until every message has
-- been printed before continuing.
waitForOutput :: OutputQ -> IO ()
waitForOutput out = do
  empty <- atomically $ isEmptyTQueue out
  if empty
    then return ()
    else do threadDelay 1000
            waitForOutput out

-----------------------------
--- Standard Output Queue ---
-----------------------------

-- stdoutQ is an output queue used for standard output.
stdoutQ :: OutputQ
stdoutQ = unsafePerformIO newTQueueIO

-- Each of the following operations correspond to a special case of the above
-- operations for stdoutQ.

say :: String -> IO ()
say = sayIO stdoutQ

sayT :: String -> STM ()
sayT = sayTo stdoutQ

processStdout :: IO ThreadId
processStdout = processOutput stdoutQ

flushStdout :: IO ()
flushStdout = flushOutput stdoutQ

waitForStdout :: IO ()
waitForStdout = waitForOutput stdoutQ
