module Passage where

-- Here is a more sophisticated concurrency mechanism built on top of Pools. The
-- design of the specialized Passage mechanism is tailor-made for solving the
-- Santa Claus problem.

import Pool

import Data.Traversable (for)
import Control.Concurrent.STM (STM, atomically)
import Control.Concurrent.STM.TMVar
  (TMVar, newEmptyTMVar, putTMVar, takeTMVar)

-- A 'Passage a' is an (unbounded) series of gates requiring a fixed number of
-- participants and an external operator.  Think of a long corridor or hallway
-- being blocked by many doors.  Participants gather in the hallway in front of
-- a door, waiting to pass it, until there is no more roof for additional
-- participants.  The operator can open the door and let all the participants
-- pass on to the next segment of the hallway, but only when the limit of
-- participants has been reached.
newtype Passage a = Pass (Pool (a, TMVar (Passage a)))
-- The data for a 'Passage a' is a fixed-size Pool containing pairs of
--
--   1. 'a' values representing the participants, and
--
--   2. TMVars of new 'Passage a's for giving each participant access to the
--      next gate in the passage.

-- Create a new passage requiring the given number of participants to pass
-- through each gate of the passage.
newPassage :: Int -> STM (Passage a)
newPassage c = do
  p <- newPool c
  return (Pass p)

-- Pass a participant of type 'a' through the first gate of a Passage, returning
-- the next segment of the Passage.
pass :: Passage a -> a -> IO (Passage a)
pass (Pass p) x = do
  ticket <- atomically newEmptyTMVar
  atomically $ enterPool p (x, ticket)
  next <- atomically $ takeTMVar ticket
  return next

-- Open the first gate of a Passage, which returns a list of all participants
-- passing through the gate, as well as the next segment of the Passage.
open :: Passage a -> STM ([a], Passage a)
open (Pass p) = do
  contents <- emptyPool p
  p' <- newPassage (poolSize p)
  xs <- for contents $ \(x, ticket) -> do
    putTMVar ticket p'
    return x
  return (xs, p')
