module Main where

import Lib
import System.Random
import Data.Char

main :: IO ()
main = do
  putStrLn "Welcome to the guessing game!"
  forever (playRound (1, 100))

-- Play a round of the guessing game, given a range of numbers to choose as the
-- secret.
playRound :: (Int, Int) -> IO ()
playRound range = do
  secret <- randomRIO range
  let (low, high) = range
  putStrLn ("I've chosen a number between " ++ show low ++ " and " ++ show high ++ ".")
  repeatUntilTrue (makeAGuess secret)
  return ()

-- Have the user make a guess at the secret number. Returns True if the guess
-- was correct, False otherwise.
makeAGuess :: Int -> IO Bool
makeAGuess secret = do
  answer <- prompt "What's my number?" safeReadInt
  case compare answer secret of
    LT -> do putStrLn "That's too low."
             return False
    GT -> do putStrLn "That's too high."
             return False
    EQ -> do putStrLn "That's it!"
             return True
-- Note that the logic of converting he user's input into a usable Int value is
-- now handled completely by 'prompt', which keeps trying until the user says
-- something sensible.
