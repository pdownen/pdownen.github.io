# Notes for Lecture 5 of
# Effective Functional Programming

... on getting it right with automated testing.


You can test your answers for Assignment 1 by

  1. adding your code to the "src" directory,

  2. renaming "test/BlackjackSpec.disable" to "test/BlackjackSpec.hs",
  
  3. updating the imports in "test/BlackjackSpec.hs" to import the correct
     modules that your code is found in (and update any types in BlackjackSpec
     to match your code, if they differ from the assignment), and
     
  4. uncommenting the specified lines in "test/Spec.hs" to test the properties
     defined in BlackjackSpec as part of the "main" test suit.
