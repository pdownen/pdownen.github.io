-- A test suite for your card game code from assignment 1.
module BlackjackSpec where
-- Note that you may not be able to use this exactly on your code, because you
-- may have defined your data types differently than I did, or implemented the
-- soft scoring rules for aces. If so, then change the Arbitrary type class
-- instances or remove the code referring to the Score data type, as appropriate
-- for your code.

import Cards
import Score
import Shuffle
import Test.QuickCheck hiding (shuffle)
import Test.Hspec
import Data.List (sort)

-- An Hspec test suit for card game functionality, testing zipping and shuffling
-- lists as well as combining and improving Scores.
blackjackSpec = do
  describe "Shuffle.shuffle" $ do
    it "preserves order when indexes are in order" $ property shuffleInOrder
    it "reverses order when indexes are reversed" $ property shuffleReverse
    it "permutes the order of the list" $ property shufflePermute

  describe "Score.Monoid Score" $ do
    it "obeys the identity law"      $ property scoreMonoidId
    it "obeys the associativity law" $ property scoreMonoidAssoc

  describe "Score.improveScore" $ do
    it "is idempotent" $
      property improveIdem
    it "lowers soft busted scores, and otherwise leaves scores unchanged" $
      property improveBust

-- In order to have your properties vary over arbitrary values of some type 'a',
-- QuickCheck needs to know how to generate arbitrary values of type 'a'! This
-- is captured by the Arbitrary type class, which has the primary method
-- 'arbitrary' like so:
--
--     class Arbitrary a where
--       arbitrary :: Gen a
--       ...
--
-- 'Gen a' is similar to 'IO a', meaning some sort of operation which may cause
-- side effects, except the side-effects of 'Gen a' are just limited to those
-- needed for generating "random" values, and doesn't allow for reading and
-- printing from the console, reading and writing files, sending information
-- over the network, etc. But because it is an IO-like type modifier, we can
-- still use a "do" to sequence operations and bind their results to variables!

-- An instance of Arbitrary for my definition of the 'Indexed i a' type. Now
-- QuickCheck knows how to generate arbitrary 'Indexed i a' values for the
-- purpose of running randomized test cases.
instance (Arbitrary i, Arbitrary a) => Arbitrary (Indexed i a) where
  arbitrary = do
    i <- arbitrary  -- Use arbitrary :: Gen i to generate an arbitrary value of
                    -- type 'i'. Note that type inference figures out the
                    -- appropriate type of 'i', and thus the appropriate
                    -- instance of 'arbitrary' to use. Also note that since 'i'
                    -- is a generic type, we must assume that Arbitrary i is
                    -- defined, as said in the pre-condition of this type class
                    -- instance.
    a <- arbitrary  -- Use arbitrary :: Gen a to generate an arbitrary value of
                    -- type 'a'. Again, type inference figures out the type, and
                    -- thus the correct instance of 'arbitrary' to use, which
                    -- may be *different* from the line above (because the types
                    -- 'i' and 'a' might be different, such as Int and
                    -- String). Since 'a' is generic, we also need to add the
                    -- assumption that an instance of Arbitrary a exists to the
                    -- pre-conditions of this Arbitrary (Indexed i a) instance.
    return (At a i) -- Now, just construct an Indexed i a value with the 'At'
                    -- constructor with the above two arbitrary values, and
                    -- return it.

-- An instance of Arbitrary for my definition of the 'Score' type. Now
-- QuickCheck knows how to generate arbitrary 'Score' values for the purpose of
-- running randomized test cases.
instance Arbitrary Score where
  arbitrary = do
    n <- arbitrary `suchThat` (>= 0)
    -- Note that not every possible value of Score (as I defined it) makes
    -- sense. In particular, the hard Score value, of type Int, should never be
    -- negative. We can restrict the generation of arbitrary values with these
    -- kinds of extra side-conditions with the 'suchThat' function. Here, I am
    -- saying that the hard part of an arbitrary Score can be any arbitrary Int
    -- value, so long as that Int is greater than or equal to 0.
    a <- arbitrary `suchThat` (all (> 0))
    -- Likewise, the soft part of my definition of Score also carries a
    -- side-condition for the Score to make sense: every Int value in the list
    -- of soft values should be positive (strictly greater than 0). The
    -- side-condition (all (> 0)) here says exactly that in Haskell. If you
    -- wanted to be more specific and say that each soft Score value has to be
    -- 10 *exactly* (since that is the only value used in practice), then you
    -- could make the side-condition more specific (all (== 0)), which would
    -- further limit the arbitrary Score values generated for testing.
    return (Score a n)

-- This property says that, for any list of values xs :: [Int], using a specific
-- list of indexes [1,2..] occuring in increasing order causes shuffle of xs to
-- return the same xs it was given.
shuffleInOrder :: [Int] -> Bool
shuffleInOrder xs = shuffle [1,2..] xs == xs

-- This property says that, for any list of values xs :: [Int], using a specific
-- list of indexes [-1,-2..] occuring in decreasing order causes shuffle of xs
-- to return the reverse xs.
shuffleReverse :: [Int] -> Bool
shuffleReverse xs = shuffle [-1,-2..] xs == reverse xs

-- This property says that, for any list of values xs::[Int] and indexes
-- is::[Int], such that 'is' is at least as long as 'xs', shuffle of is and xs
-- is a permutation of of xs, where we ignore the order of the two lists by
-- sorting both.
shufflePermute :: [Int] -> [Int] -> Property
shufflePermute is xs = length is >= length xs
                       ==>
                       sort (shuffle is xs) == sort xs
-- Note the potential pitfalls! If we do not receive enough random index numbers
-- (is) to cover the entire list of values we want to shuffle (xs), then this
-- property will fail because some inputs from xs will be dropped from the
-- result of (shuffle is xs). That's because shuffle relies on putting together
-- is and xs as (zip is xs), and zip is defined to drop any excess elements that
-- go beyond the length of the other list. By adding the extra pre-condition
-- (using the ==> operator), we can say that this property is only guarenteed to
-- hold when we get at least as many index numbers as values to shuffle (length
-- is >= length xs).

-- This property says that the instance of Monoid Score satisfies the Monoid
-- identity law.
scoreMonoidId :: Score -> Bool
scoreMonoidId s = mempty `mappend` s == s && s `mappend` mempty == s
-- Note, if you use 'improveScore' in the definition of 'mappend', then this
-- property will no longer be true! (Because there are some scores s where s is
-- not equal to improveScore s, otherwise what would be the point of
-- improveScore!) This shows the importance of testing: this fact did not even
-- occur to me before running the tests, but once I saw the counter-example it
-- was obvious.

-- This property says that the instance of Monoid Score satisfies the Monoid
-- associativity law.
scoreMonoidAssoc :: Score -> Score -> Score -> Bool
scoreMonoidAssoc s1 s2 s3 =
  (s1 `mappend` s2) `mappend` s3 == s1 `mappend` (s2 `mappend` s3)
-- Note that, using my definition of the Score data type, using 'improveScore'
-- in the definition of 'mappend' will also cause this property to fail! This is
-- because the list of soft scores contains different Int values, not all equal
-- to 10. The extra generality makes it possible for associativity to fail, but
-- only rarely, where I only saw the failure on occasional runs of the tests. I
-- also did not even think of this possibility when originally writing the code,
-- and the counter-example generated by QuickCheck helped me to understand
-- better what was going on. In other words, property-based testing helped me to
-- develop better code for not much extra work. On the other hand, the
-- counter-example does not always come up even when generating 100 random test
-- cases, which shows the weakness of relying only on a limited batch of tests
-- (larger than specific test cases, but still relatively small in the grand
-- scheme of things).

-- This property says that improveScore is "idempotent", meaning that applying
-- it twice to any value is the same thing as applying it once to that value. Or
-- in other words, an improved score can be improved no more.
improveIdem :: Score -> Bool
improveIdem s = improveScore (improveScore s) == improveScore s

-- This property says that improveScore *will* lower any busted soft score (but
-- it still may be busted anyway), and will leave hard or non-busted scores
-- alone.
improveBust :: Score -> Bool
improveBust s = if isBust s && isSoft s
                then scoreValue s' < scoreValue s
                else scoreValue s' == scoreValue s
  where s' = improveScore s
