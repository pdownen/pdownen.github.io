-- Here is a specification test suite for some functions

import Test.QuickCheck
import Test.Hspec
import Data.List
import Control.Exception

-- Include this module if you also want to test your Blackjack code.
--
-- import BlackjackSpec


-- For the *complete* test suite, test some properties on the Prelude functions
-- below, as well as as on the Blackjack code we have written, which are tested
-- in the BlackjackSpec module.
main = hspec $ do
  fancySpec
  -- blackjackSpec -- Uncomment this line to also run the blackjack test suit

-- A simple test suite using QuickCheck. Each line of the test suite uses
-- QuickCheck to generate many test cases for a testable property. The most
-- basic testable property is just an expression returning a boolean value: True
-- passes and False fails. The third possibility of a boolean expression is
-- encountering some sort of run-time error (like division by zero), which also
-- counts as a failure. In addition to plain boolean values (which represent a
-- particular test case) functions from some input to a testable property are
-- also testable properties. For these testable functions, QuickCheck will
-- generate many inputs and check if the function returns true on each of them,
-- so long as QuickCheck knows how to generate "arbitrary" input values.
simpleMain :: IO ()
simpleMain = do
  quickCheck True                   -- This succeeds because of the True value.
  quickCheck False                  -- This fails because of the False value.
  quickCheck (error "boom" :: Bool) -- This fails because of the run-time error.
  quickCheck doubleReverse          -- This succeeds because it is a true
                                    -- property, every test case that QuickCheck
                                    -- can come up with will result in
                                    -- doubleReverse returning True.
  quickCheck singleReverse          -- This fails because there are *many*
                                    -- counter-examples causing singleReverse to
                                    -- return False, which are fairly easy for
                                    -- QuickCheck to find.
  quickCheck reversePermute         -- This property will also succeed, because
                                    -- no counter-examples exist.

-- A fancy test suite using Hspec on top of QuickCheck. Each part of the "hspec"
-- specification describes a particular function or piece of functionality, and
-- inside of each of those parts is a particular specification on what "it"
-- does, starting with a descriptive string of the specification and then either
-- an "example" (a particular test case) or a "property" (a more general test
-- that can vary over many possible inputs). More documentation on Hspec can be
-- found at http://hspec.github.io/.
fancySpec :: Spec
fancySpec = do
  describe "Prelude.head" $ do
    it "returns the first element of a list" $ do
      head [23 ..] `shouldBe` (23 :: Int)

    it "returns the first element of an *arbitrary* list" $
      property $ \x xs -> head (x:xs) == (x :: Int)

    it "throws an exception if used with an empty list" $ do
      evaluate (head []) `shouldThrow` anyException

  describe "Prelude.reverse" $ do
    it "returns the same list when composed with itself" $
      property doubleReverse

    it "returns the same list it was given" $ property singleReverse
    -- Remember, this property is wrong, because there are counter-examples!

    it "permutes the list" (property reversePermute)

    it "swaps the first and last elements" $ property reverseFirstLast

-- This property tests that, for any input list xs :: [Int], is it true that
-- reversing xs twice is equal to the original xs? (Yes it is.)
doubleReverse :: [Int] -> Bool
doubleReverse xs = reverse (reverse xs) == xs

-- This property tests that, for any input list xs :: [Int], is it true that the
-- reverse of xs is equal to the original xs? (Not, it isn't).
singleReverse :: [Int] -> Bool
singleReverse xs = reverse xs == xs

-- This property tests that reverse is a permutation, meaning that for any input
-- list xs :: [Int], is the reverse of xs equal to xs, when both lists are
-- sorted to remove differences of ordering? (Yes it is.)
reversePermute :: [Int] -> Bool
reversePermute xs = sort xs == sort (reverse xs)

-- This property tests that reverse swaps the first and the last elements of a
-- list. Note that the statement of this property is wrong/doesn't make sense
-- specifically for the edge case of the empty list, which has no first or last
-- elements to begin with! Instead of saying that the property is wrong in
-- general (when it is only wrong for the empty list), we can add a
-- pre-condition to the property to throw out that case with the (==>) operator:
-- the left-hand side of ==> is the pre-condition and the right-hand side is the
-- property we want to test, under the assumption that the pre-condition is
-- true.
reverseFirstLast :: [Int] -> Property
reverseFirstLast xs = not (null xs)
                      ==>
                      head xs == last (reverse xs)
                      &&
                      last xs == head (reverse xs)
-- Note that the ==> is fancier than just saying that the test happens to
-- succeed in the case that the pre-condition is False.  QuickCheck has special
-- support for the ==> pre-condition operator, and will not count test cases
-- which violate the pre-condition, so that it still check the desired amount of
-- meaningful test cases.  For example, if you had instead written the property
-- "either the pre-condition is false or the test is true" using the boolean
-- (||) operator and there are many conditions where your pre-condition might be
-- False, then it is easy to only run a handful of *real* tests (out of the 100
-- or so that QuickCheck will try by default) that satisfy the pre-condition. By
-- instead using the pre-condition operator (==>), and QuickCheck is trying 100
-- cases, it will make sure 100 cases that satisfy the pre-condition are tried
-- before concluding.
