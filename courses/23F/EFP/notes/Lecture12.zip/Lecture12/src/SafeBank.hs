module SafeBank where

import SyncOut

import Control.Concurrent
import Control.Concurrent.STM
import Control.Concurrent.STM.TVar
import Control.Monad
import System.Random
import System.IO.Unsafe

-- Here is a safer version of the banking system from RiskyBank. The key
-- solution is that we want the combination of read and write operations in
-- withdrawals, deposits, and transfers to be *atomic*, meaning that they will
-- run as if the program was totally sequential. Concurrency is okay, so long as
-- no other thread jumps in between a read and a write, and tramples over the
-- references used by an atomic transaction.

-- In order to put together atomic transactions, Haskell provides an alternative
-- mode of concurrency from IO: Software Transactional Memory (STM). STM is a
-- type-modifier like IO which allows for side-effectful programming and
-- concurrency. The difference is that an STM action can be run *atomically*,
-- meaning that the entire action runs "without interference" or not at all. The
-- primary operation to enforce an atomic transaction is
--
--     atomically :: STM a -> IO a
--
-- which means to run a transaction and check that it has a consistent view of
-- shared resources. If it turns out that something goes wrong during the atomic
-- STM transaction (due to a race condition, or if it gets blocked indefinitely
-- due to waiting for a resource that will never come), then the entire atomic
-- transaction is undone, and tried again.

-- To implement this feature (undo and try again), STM only allows for a limited
-- range of possible actions; essentially just reads and writes to different
-- forms of shared resources or references. The reason for this restriction is
-- that not every kind of action can be undone. For example, if a value is
-- written to an address in memory, it is easy enough to rewrite the old value
-- back to it. But if a message is printed out, or a packet is sent across the
-- network, or a motor is turned on, then these actions have a permanent impact
-- on the world outside the processor and can't be undone. In other words, every
-- STM action is an IO action (via 'atomically') but not every IO action can be
-- made into an undoable STM action. So this is an instance where the generic
-- idea of Monads as a way of structuring actions give us a way to isolate a
-- certain limited view of real side-effects from the big world of IO. The
-- 'atomically' function only makes sense because we *know* (by the type STM a
-- of its input) that running the given action cannot interact with the outside
-- world.

-- To make the risky bank account system into a safe one, we need to remove the
-- race condition hidden within withdrawals and deposits. STM makes this easy to
-- do by making them transactional, which adds the extra layer of protection
-- before the update to a bank account balance is "committed". To make the
-- change from Risky to Safe, in this case, you only need to do a
-- search-and-replace for basic IO primitives to use STM primitives
-- instead. Rather than IORefs, you can use TVars which are the transactional
-- counterpoint to plain old references. Likewise, the names of the
-- new/read/write operations need to be updated (instead of
-- newIORef/readIORef/writeIORef, use newTVarIO/readTVar/writeTVar). And when
-- you go to use one of the bank transactions (like transfer) wrap it in an
-- "atomically" to get a threadsafe IO action that runs as if it was sequential
-- code, even though other threads may be running concurrently with it.

-- But there's one more thing! Note that, by the above explanation, there is no
-- way for an STM action to interact directly with a user, because that can't be
-- undone in the case that a race condition happened to occurred. There needs to
-- be at least a layer of indirection that separates "here is a message for the
-- user" from "actually print out the message to the user permanently". The
-- SyncOut module that is included with this code provides such a function:
--
--     sayT :: String -> STM ()
--
-- sayT is exactly like say, but because it lives in STM instead of IO, a sayT
-- message may be undone, and never shown in case the transaction it's part of
-- is undone. Changing all calls to 'say' with 'sayT' is the last step to fix
-- the race conditions in the risky bank code, while still providing interaction
-- with a user.

type Balance = Integer
type Name    = String
data Account = Acct Name (TVar Balance)

name :: Account -> Name
name (Acct n _) = n

balance :: Account -> TVar Balance
balance (Acct _ b) = b

newAccount :: Name -> Balance -> IO Account
newAccount name bal = do
  ref <- newTVarIO bal
  return (Acct name ref)

printAccount :: Account -> STM ()
printAccount (Acct n ref) = do
  b <- readTVar ref
  sayT $ "Name: " ++ n ++ ", Balance: $" ++ show b

printAccountNow acct = do
  atomically (printAccount acct)
  flushStdout

jack, jill :: Account
jack = unsafePerformIO (newAccount "Jack" 1000)
jill = unsafePerformIO (newAccount "Jill" 2000)

deposit :: Integer -> Account -> STM ()
deposit amount acct = do
  sayT $ "Depositing $" ++ show amount ++ " to " ++ name acct
  old <- readTVar (balance acct)
  writeTVar (balance acct) (old+amount)
  new <- readTVar (balance acct)
  sayT $
    name acct ++ "'s deposit completed (" ++
    show old ++ " + " ++ show amount ++ " = " ++ show new ++ ")"
  return ()

withdraw :: Integer -> Account -> STM Bool
withdraw amount acct = do
  old <- readTVar (balance acct)
  if old < amount
    then do
      sayT $
        "Can't withdraw $" ++ show amount ++ " from " ++ name acct ++
        " (insufficient funds)"
      return False
    else do
      sayT $ "Withdrawing $" ++ show amount ++ " from " ++ name acct
      writeTVar (balance acct) (old-amount)
      new <- readTVar (balance acct)
      sayT $
        name acct ++ "'s withdrawal completed (" ++
        show old ++ " - " ++ show amount ++ " = " ++ show new ++ ")"
      return True

transfer :: Integer -> Account -> Account -> STM Bool
transfer amount from to = do
  sayT $
    "Transferring $" ++ show amount ++
    " from " ++ name from ++
    " to " ++ name to
  sufficient <- withdraw amount from
  if sufficient
    then do deposit amount to; return True
    else return False

backAndForth :: Integer -> Account -> Account -> IO ()
backAndForth amount a b = do
  outp <- processStdout
  aTob <- forkIO $ forever $ do
    atomically (transfer amount a b)
    delay
  bToa <- forkIO $ forever $ do
    atomically (transfer amount b a)
    delay
  _ <- getLine -- Wait for user input to stop
  killThread aTob
  killThread bToa
  waitForStdout
  killThread outp
  return ()

delay :: IO ()
delay = do
  wait <- randomRIO (10^3,10^6)
  threadDelay wait

-- Try out funnel2 now that the rest of the code has been converted to STM, and
-- see that no money is spontaneously generated or lost to the void!
funnel2 :: Integer -> Account -> Account -> IO ()
funnel2 amount a b = do
  done1 <- newEmptyMVar
  done2 <- newEmptyMVar
  forkIO $ do
    repeatUntilFalse (atomically (transfer amount a b))
    putMVar done1 ()
  forkIO $ do
    repeatUntilFalse (atomically (transfer amount a b))
    putMVar done2 ()
  takeMVar done1
  takeMVar done2
  flushStdout
  return ()

repeatUntilFalse :: IO Bool -> IO ()
repeatUntilFalse act = do
  b <- act
  if b
    then repeatUntilFalse act
    else return ()
