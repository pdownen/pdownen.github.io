module Main where

-- The Santa Claus problem[1]:
--
--     Santa repeatedly sleeps until wakened by either all of his nine reindeer,
--     back from their holidays, or by a group of three of his ten elves. If
--     awakened by the reindeer, he harnesses each of them to his sleigh,
--     delivers toys with them and finally unharnesses them (allowing them to go
--     off on holiday). If awakened by a group of elves, he shows each of the
--     group into his study, consults with them on toy R&D and finally shows
--     them each out (allowing them to go back to work). Santa should give
--     priority to the reindeer in the case that there is both a group of elves
--     and a group of reindeer waiting.
--
-- [1] https://www.schoolofhaskell.com/school/advanced-haskell/beautiful-concurrency/4-the-santa-claus-problem

-- Code included in these lecture notes
import SyncOut (say, sayT, processStdout, waitForStdout)
import Passage (Passage, newPassage, pass, open)

-- Standard library functions
import Data.List (init, last, intercalate)
import Data.Traversable (for)
import Control.Applicative ((<|>))
import Control.Monad (forever)
import Control.Concurrent (threadDelay, forkIO, killThread)
import Control.Concurrent.STM (STM, atomically)
import System.Random (randomRIO)

-- Representation of elves and reindeer.  The reindeer are given their usual
-- names, and the elves are represented by a unique number distinguishing them
-- from one another.
data Elf      = Elf Int deriving Show
data Reindeer = Dasher
              | Dancer
              | Prancer
              | Vixen
              | Comet
              | Cupid
              | Donner
              | Blizten
              | Rudolph
  deriving (Show, Eq, Enum, Bounded)

-- Santa's two tasks include
data Task
  = Delivery (Passage Reindeer)  -- Delivering toys (with Reindeer)
  | Research (Passage Elf)       -- Toy R&D (with Elves)

-- Wait for a random number of seconds within the given range.
wait :: Int -> Int -> IO ()
wait n m = do
  delay <- randomRIO (n*10^6, m*10^6)
  threadDelay delay

-- Say some additional side message for more diagnostic information.
aside :: Show a => a -> String -> IO ()
aside actor message = say $ "    " ++ show actor ++ " " ++ message
-- aside _ _ = return ()
-- Use the above commented-out definition of 'aside' for a less noisy output.

-- An elf waits to pass into the study, meets with Santa, and then passes back
-- into the workshop once dismissed.
elf :: Elf -> Passage Elf -> IO ()
elf me study = forever $ do
  wait 1 20
  aside me "is ready for toy R&D"
  workshop <- pass study me
  say $ show me ++ " meets with Santa in the study"
  pass workshop me
  aside me "runs off to work on more toys"
  wait 5 20

-- A reindeer waits to be tied up to the sled, pulls Santa to deliver toys, and
-- then waits to be unharnessed from the sled to go on holiday.
reindeer :: Reindeer -> Passage Reindeer -> IO ()
reindeer me sled = forever $ do
  wait 1 20
  aside me "is ready to go for a ride"
  harness <- pass sled me
  say $ show me ++ " pulls the sleigh"
  pass harness me
  aside me "scampers off to play reindeer games"
  wait 10 30

-- Santa waits for either all the reindeer to gather at the sled, or a group of
-- elves to wait by his study (in that order of preference).
reindeerWakeSanta :: Passage Reindeer -> STM (Passage Reindeer)
reindeerWakeSanta sled = do
  (rdeer, harness) <- open sled
  sayT $ replicate 40 '<'
  sayT $ "Santa ties " ++ listed rdeer ++ " to the sled"
  return harness

elvesWakeSanta :: Passage Elf -> STM (Passage Elf)
elvesWakeSanta study = do
  (elves, workshop) <- open study
  sayT $ replicate 40 '<'
  sayT $ "Santa takes " ++ listed elves ++ " to his study"
  return workshop

wakeSanta :: Passage Reindeer -> Passage Elf -> STM Task
wakeSanta sled study
  =  Delivery <$> reindeerWakeSanta sled
 <|> Research <$> elvesWakeSanta study

--  When all reindeer are ready, Santa takes them to deliver toys.
santaDelivery :: Passage Reindeer -> IO ()
santaDelivery harness = do
  say $ "Santa: \"HO HO HO! Merry Christmas!\""
  wait 2 6
  say $ "Santa delivers toys to good little children"
  wait 5 10
  (rdeer, _) <- atomically $ open harness
  say $ "Santa unharnesses " ++ listed rdeer
  say $ replicate 40 '>'

-- When enough elves are ready, Santa takes them to do toy R&D.
santaResearch :: Passage Elf -> IO ()
santaResearch workshop = do
  wait 1 3
  say $ "Santa plans out toy production"
  wait 1 3
  (elves, _) <- atomically $ open workshop
  say $ "Santa sends " ++ listed elves ++ " to the workshop"
  say $ replicate 40 '>'

-- Santa spends his vaction time sleeping, until he is woken up.  Depending on
-- who wakes him, he has a different task to do before going back to sleep.
santa :: Passage Reindeer -> Passage Elf -> IO ()
santa sled study = forever $ do
  task <- atomically (wakeSanta sled study)
  case task of
    Delivery harness  -> santaDelivery harness
    Research workshop -> santaResearch workshop

-- Display a list of (Showable) elements in English prose.
listed :: Show a => [a] -> String
listed []    = ""
listed [x]   = show x
listed [x,y] = show x ++ " and " ++ show y
listed xs    = intercalate ", " (beginning ++ ["and " ++ final])
  where final     = show (last xs)
        beginning = map show (init xs)

-- Run a simulation of the North Pole.
main :: IO ()
main = do
  let rdeer = [minBound ..]
  let e = 10   -- total number of elves
  let s = 3    -- number of elves allowed in Santa's study at one time

  -- Initialize passages and output process
  sled  <- atomically $ newPassage $ length rdeer
  study <- atomically $ newPassage s
  outp  <- processStdout

  -- Start up each elf
  elves <- for [1..e] $ \i -> do
    forkIO $ elf (Elf i) study

  -- Start up each reindeer
  reindeer <- for rdeer $ \r -> do
    forkIO $ reindeer r sled

  -- Start up Santa Clause
  clause <- forkIO $ santa sled study

  -- Wait for user to press enter to end the simulation
  getLine

  -- Shut down all processes
  killThread clause
  for reindeer killThread
  for elves killThread
  waitForStdout
  killThread outp
