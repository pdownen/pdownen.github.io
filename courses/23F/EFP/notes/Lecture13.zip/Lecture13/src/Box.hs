module Box where

-- Usually, concurrency frameworks/libraries come with many different primitive
-- mechanisms for organizing coordination, synchronization, and communication
-- between processes. Examples include locks, semaphores, channels, and
-- queues. To solve a particular concurrent problem, you need to select which
-- primitive mechanisms apply to your situation and let you write a program
-- without deadlocks or race conditions.

-- With Software Transactional Memory (STM), the only essential primitive
-- mechanisms you need are:
--
--   * Transactional variables (TVars) which have the same interface as regular
--     IO references (IORefs), but live in STM instead,
--
--   * The 'atomically' operation for converting an STM action into an "atomic"
--     real IO action, and
--
--   * The STM instances of the effect type class interfaces (Functor,
--     Applicative, Monad, and Alternative).
--
-- All the other concurrency mechanisms in the STM library can (and are) built
-- on top of these. For example, this 'Box' module is a reimplementation of
-- 'TMVar a' (transactional mutex variable) from the standard STM library.  A
-- TQueue is (essentially) a TVar containing a purely functional FIFO list.  The
-- advantage of having simple, but composable, primitives is that you can build
-- your own custom concurrency mechanisms if none of the standard ones nicely
-- fit your problem.

-- Built-in primitives for STM-based concurrency
import Control.Concurrent.STM (STM, check, retry)
import Control.Concurrent.STM.TVar
  (TVar, newTVar, writeTVar, readTVar)

-- A 'Box a' is a single transactional variable that might contain a value of
-- type 'a', or Nothing.
data Box a = Box (TVar (Maybe a))

-- Create a brand new 'Box a' containing Nothing.
newBox :: STM (Box a)
newBox = do
  var <- newTVar Nothing
  return (Box var)

-- Take the contents of a 'Box a' only if something is there.  If the Box
-- contains Nothing, then retry again later.
takeBox :: Box a -> STM a
takeBox (Box var) = do
  contents <- readTVar var
  case contents of
    Just x  -> return x
    Nothing -> retry

-- Fill an empty 'Box a' with a value of type 'a'.  If the Box is currently
-- full, then retry again later.
fillBox :: Box a -> a -> STM ()
fillBox (Box var) x = do
  contents <- readTVar var
  case contents of
    Nothing -> writeTVar var (Just x)
    Just _  -> retry
