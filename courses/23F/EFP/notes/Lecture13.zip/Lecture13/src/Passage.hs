module Passage where

-- Here is a more sophisticated concurrency mechanism built on top of Pools. The
-- design of the specialized Passage mechanism is tailor-made for solving the
-- Santa Claus problem.

-- Other concurrency structures defined in these lecture notes
import Pool
import Box

-- Built-in STM primitives
import Control.Concurrent.STM (STM, atomically)

-- Code from the standard to write 'for' loops
import Data.Traversable (for)


-- A 'Passage a' is an (unbounded) series of gates requiring a fixed number of
-- participants and an external operator.  Think of a long corridor or hallway
-- being blocked by many doors.  Participants gather in the hallway in front of
-- a door, waiting to pass it, until there is no more roof for additional
-- participants.  The operator can open the door and let all the participants
-- pass on to the next segment of the hallway, but only when the limit of
-- participants has been reached.
newtype Passage a = Pass (Pool (a, Ticket a))
-- The data for a 'Passage a' is a fixed-size Pool containing pairs of
--
--   1. 'a' values representing the participants, and
--
--   2. A Ticket giving each participant access to the next gate in the passage.

-- A Ticket is just a Box containing a pointer to the next passageway.
type Ticket a = Box (Passage a)

-- Create a new passage requiring the given number of participants to pass
-- through each gate of the passage.
newPassage :: Int -> STM (Passage a)
newPassage c = do
  p <- newPool c
  return (Pass p)

-- How many 'a's can fit through the Passage at one time.
passageSize :: Passage a -> Int
passageSize (Pass p) = poolSize p


-- An individual of type 'a' entering a Passage and getting a fresh Ticket.
enterPassage :: Passage a -> a -> STM (Ticket a)
enterPassage (Pass p) x = do
  ticket <- newBox
  enterPool p (x, ticket)
  return ticket

-- An individual using their Ticket to move on to the next gate in the Passage,
-- which is returned.
exitPassage :: Ticket a -> STM (Passage a)
exitPassage ticket = takeBox ticket

-- An individual passes through the first gate of a Passage, returning the next
-- segment of the Passage.
pass :: Passage a -> a -> IO (Passage a)
pass p x = do
  ticket <- atomically (enterPassage p x)
  atomically (exitPassage ticket)

-- Open the first gate of a Passage to the next one, which returns a list of all
-- participants passing through the gate.
openTo :: Passage a -> Passage a -> STM [a]
openTo (Pass p) next = do
  contents <- emptyPool p
  xs <- for contents $ \(x, ticket) -> do
    fillBox ticket next
    return x
  return xs

-- Open the first gate of a Passage to a newly generated one, returning both the
-- participants passing through the gate as well as the next segment of the
-- passageway.
open :: Passage a -> STM ([a], Passage a)
open p = do
  p' <- newPassage (passageSize p)
  xs <- p `openTo` p'
  return (xs, p')
