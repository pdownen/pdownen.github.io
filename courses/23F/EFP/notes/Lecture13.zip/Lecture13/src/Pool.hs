module Pool where

-- This module looks at building a specialized concurrency mechanism called a
-- Pool.  A Pool is a generalization of a Box, in that it can hold a specific
-- chosen number of things before it is full, and it can only be emptied once
-- completely full.

-- You can't just reuse simpler concurrency mechanisms, like a Box (also known
-- as a TMVar) or a TQueue, because they are either too specific or too general.

--   * A Pool can't be a TQueue, because a general queue doesn't have a limit on
--     how many elements it can hold.  In contrast, an attempt at entering a
--     full Pool needs to block, and wait until the Pool has been emptied so
--     there is room again to enter it.  Furthermore, the TQueue should only be
--     emptied when it is at a specific amount, never before or after, which is
--     not an operation of the queue API.

--   * A Pool can't be a list of individual Boxes (Pool a = [Box a]) because you
--     have no idea which of the several boxes will be filled.  This happens
--     when there are a larger number of processes that want to enter a pool
--     than the total capacity.  For example, if 3 processes are all trying to
--     fill in 2 Boxes, there aren't enough Boxes to assign each process its own
--     private Box.  Since we have no way of predicting which 2 processes will
--     be ready first, and need to act in a first-come-first serve basis, there
--     is no "static" way to assign shared Boxes to processes in a way that will
--     always fill them ASAP.

-- Built-in primitives for STM-based concurrency
import Control.Concurrent.STM (STM, check)
import Control.Concurrent.STM.TVar
  (TVar, newTVar, writeTVar, readTVar)

-- A 'Pool a' is a gathering of 'a's up to a fixed total size. A Pool is like an
-- unordered version of a bounded Queue, where everything in the pool must be
-- emptied out at once it is full in no particular order.

data Pool a
  = Pool
    Int         -- Total capacity of the pool
    (TVar Int)  -- Number of 'a's currently in the pool
    (TVar [a])  -- The pool of 'a's

-- Create a new Pool of the given capacity.
newPool :: Int -> STM (Pool a)
newPool c = do
  num <- newTVar 0
  elem <- newTVar []
  return (Pool c num elem)

-- The total capacity of a pool.
poolSize :: Pool a -> Int
poolSize (Pool c _ _) = c

-- Enter a Pool with room remaining. enterPool blocks if the Pool is full (that
-- is, at capacity).
enterPool :: Pool a -> a -> STM ()
enterPool (Pool c num elems) x = do
  n <- readTVar num
  check (n < c)
  xs <- readTVar elems
  writeTVar num (n+1)
  writeTVar elems (x:xs)
  return ()

{-
check True  = return ()
check False = retry
-}

-- Empty the entire contents of a completely full Pool all at once. emptyPool
-- blocks if the Pool is not full (there is still room to add more elements).
emptyPool :: Pool a -> STM [a]
emptyPool (Pool c num elems) = do
  n <- readTVar num
  check (n == c)
  xs <- readTVar elems
  writeTVar elems []
  writeTVar num 0
  return xs
