module Desugaring where

import qualified Data.Map as M

----------------
-- Desugaring --
----------------

-- Recall the phonebook example from lecture 4.

type Name = String
type PhoneNumber = String
type PhoneBook = M.Map Name PhoneNumber

book, book' :: PhoneBook

book = M.fromList
       [("betty","555-2938")
       ,("bonnie","452-2928")
       ,("rodger","493-2928")
       ,("lucille","205-2928")
       ,("michael","939-8282")
       ,("penny","853-2492")
       ]

book' = M.insert "george" "252-8169" book

lookupTwo :: Name -> Name -> PhoneBook -> Maybe (Name, Name)
lookupTwo n1 n2 bk = do
  p1 <- M.lookup n1 bk
  p2 <- M.lookup n2 bk
  return (p1, p2)

-- Let's desugar the do notation and inline the definition of the Monad
-- operations for to see that it is just shorthand for a cascade of cases.

-- First, rewriting the 'do' into >>=.
lookupTwo1 n1 n2 bk =
  M.lookup n1 bk >>= \p1 ->
  M.lookup n2 bk >>= \p2 ->
  return (p1, p2)

-- Recall the Monad instance for Maybe in the standard library (using a case)
--
--     instance Monad Maybe where
--       return x = Just x
--
--       m >>= f  = case m of
--         Nothing -> Nothing
--         Just x  -> f x

-- Now, inlining the definition of >>= and return
lookupTwo2 n1 n2 bk =
  case M.lookup n1 bk of
    Nothing -> Nothing
    Just x -> (\p1 -> case M.lookup n2 bk of
                  Nothing -> Nothing
                  Just y  -> (\p2 -> Just (p1, p2)) y
              ) x

-- And finally cleaning up the application of a function (\p1 -> ...) to an
-- argument x by substituting x for p1
lookupTwo3 n1 n2 bk =
  case M.lookup n1 bk of
    Nothing -> Nothing
    Just x -> case M.lookup n2 bk of
                Nothing -> Nothing
                Just y  -> Just (x, y)

-- Recall the coin flip example

type NonDet a = [a]

data Coin = Heads | Tails deriving (Show, Eq, Ord)

coinFlip :: NonDet Coin
coinFlip = [Heads, Tails]

twoCoinFlips :: NonDet (Coin, Coin)
twoCoinFlips = do
  c1 <- coinFlip
  c2 <- coinFlip
  return (c1, c2)

-- Let's desugar the do notation and inline the definition of the Monad
-- operations for to see that it is just shorthand for mapping and concatenating.

-- First, rewrite the 'do' in terms of >>=
twoCoinFlips1 =
  coinFlip >>= \c1 ->
  coinFlip >>= \c2 ->
  return (c1, c2)

-- Recall, the Monad instance for lists in the standard library is
--
--     instance Monad [] where
--        return x = [x]
--        xs >>= f = [ y | x <- xs, y <- f x ]

-- Next, inline the definition of the second >>=
twoCoinFlips2 =
  coinFlip >>= \c1 ->
  [ y | c2 <- coinFlip, y <- return (c1, c2) ]

-- Since return (c1, c2) = [(c1, c2)] and coinFlip = [Heads, Tails],
-- we can simplify the list comprehension.
twoCoinFlips3 =
  coinFlip >>= \c1 ->
  [ y | c2 <- [Heads, Tails], y <- [(c1, c2)] ]

twoCoinFlips4 =
  coinFlip >>= \c1 ->
  [(c1, Heads), (c1, Tails)]

-- Inline the definition >>= again and simplify the list comprehension.
twoCoinFlips5 =
  [ x | c1 <- coinFlip, x <- [(c1, Heads), (c1, Tails)] ]

twoCoinFlips6 =
  [ x | c1 <- [Heads, Tails], x <- [(c1, Heads), (c1, Tails)] ]

twoCoinFlips7 = [(Heads, Heads), (Heads, Tails), (Tails, Heads), (Tails, Tails)]


-- We can do the same desugaring for many coin flips
manyFlips :: Int -> [[Coin]]
manyFlips 0 = return []
manyFlips n = do
  cs <- manyFlips (n-1)
  c <- coinFlip
  return (c:cs)

-- Desugar 'do'
manyFlips1 0 = return []
manyFlips1 n =
  manyFlips1 (n-1) >>= \cs ->
  coinFlip >>= \c ->
  return (c:cs)

-- Inline definitions of return and the second >>=
manyFlips2 0 = [[]]
manyFlips2 n =
  manyFlips2 (n-1) >>= \cs ->
  [ y | c <- coinFlip, y <- [c:cs] ]

-- Inline definition of coinFlip and simplify
manyFlips3 0 = [[]]
manyFlips3 n =
  manyFlips3 (n-1) >>= \cs ->
  [ y | c <- [Heads, Tails], y <- [c:cs] ]

manyFlips4 0 = [[]]
manyFlips4 n =
  manyFlips4 (n-1) >>= \cs ->
  [Heads:cs, Tails:cs]

-- Inline the definition of >>=  again
manyFlips5 0 = [[]]
manyFlips5 n = [ x
               | cs <- manyFlips5 (n-1),
                 x  <- [Heads:cs, Tails:cs] ]

