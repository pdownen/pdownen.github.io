module Lib where

import Control.Applicative
import Numeric.Probability.Distribution
import Numeric.Probability.Percentage

data Tree a = Leaf
            | Branch (Tree a) a (Tree a)
            deriving Show

findDFS :: (a -> Bool) -> Tree a -> Maybe a
findDFS p Leaf = Nothing
findDFS p (Branch t x u)
  | p x       = Just x
  | otherwise = case findDFS p t of
      Just y  -> Just y
      Nothing -> findDFS p u


findDFS' :: (a -> Bool) -> Tree a -> Maybe a
findDFS' p Leaf = Nothing
findDFS' p (Branch t x u)
  | p x       = Just x
  | otherwise = findDFS' p t <|> findDFS' p u

-- Recall, the Alternative instance for Maybe in the standard library is
--
--     instance Alternative Maybe where
--       empty = Nothing
--
--       Nothing <|> y = y
--       x       <|> y = x

findAll :: (a -> Bool) -> Tree a -> [a]
findAll p Leaf = []
findAll p (Branch t x u)
  | p x       = findAll p t <|> [x] <|> findAll p u
  | otherwise = findAll p t <|> findAll p u

-- Recall, the Alternative instance for lists in the standard library is
--
--     instance Alternative [] where
--       empty = []
--
--       xs <|> ys = xs ++ ys


growTree :: (a -> a) -> (a -> a) -> a -> Int -> Tree a
growTree f g x 0 = Leaf
growTree f g x n = Branch
                   (growTree f g (f x) (n-1))
                   x
                   (growTree f g (g x) (n-1))

integers :: Int -> Tree Integer
integers n = growTree (subtract 1) (+ 1) 0 n

{-
integers 3
=
Branch
  (Branch
    (Branch Leaf (-2) Leaf)
    (-1)
    (Branch Leaf 0 Leaf))
  0
  (Branch
    (Branch Leaf 0 Leaf)
    1
    (Branch Leaf 2 Leaf))
-}

type NonDet a = [a]

-- Note, the Monad instance for lists in the standard library is
--
--     instance Monad [] where
--        return x = [x]
--        xs >>= f = [ y | x <- xs, y <- f x ]

data Coin = Heads | Tails deriving (Show, Eq, Ord)

coinFlip :: NonDet Coin
coinFlip = [Heads, Tails]

twoCoinFlips :: NonDet (Coin, Coin)
twoCoinFlips = do
  c1 <- coinFlip
  c2 <- coinFlip
  return (c1, c2)
         
manyFlips 0 = return []
manyFlips n = do
  c <- coinFlip
  cs <- manyFlips (n-1)
  return (c:cs)

-- Defined in the Control.Monoid module
guard :: Bool -> NonDet ()
guard True  = return ()
guard False = empty -- []

pathsWhere :: (a -> Bool) -> Tree a -> NonDet [a]
pathsWhere p Leaf = return []
pathsWhere p (Branch t x u) = do
  guard (p x)
  path <- pathsWhere p t <|> pathsWhere p u
  return (x:path)

-----------------------------
-- Probability Simulations --
-----------------------------

-- 'Dist a' means a probabilistic distribution of potential 'a'
-- values.  This can be represented as a list of the different
-- possible 'a' values associated with their individual probability of
-- occuring.

-- A uniform distribution between multiple options. A coin can be
-- either Heads or Tails, with equal probability.
coin :: Dist Coin
coin = uniform [Heads, Tails]

-- Flipping multiple coins, and see how each coin landed as Heads or Tails.
coins :: Int -> Dist [Coin]
coins 0 = return []
coins n = do
  c <- coin
  cs <- coins (n-1)
  return (c:cs)

-- Counting the number of heads that comes from multiple coin flips.
numHeads :: Int -> Dist Int
numHeads n = do
  cs <- coins n
  return (length [ () | c <- cs, c == Heads])

-- Roll a single die with a chosen number of sides. An x-sided die has
-- a uniform probability of showing any number between 1 and x.
die :: Int -> Dist Int
die x = uniform [1..x]

-- Roll multiple dice and see which value each one shows.
dice :: Int -> Int -> Dist [Int]
dice 0 x = return []
dice n x = do
  d <- die x
  ds <- dice (n-1) x
  return (d:ds)

-- Roll multiple dice and add them all up.
n `d` x = do
  rolls <- dice n x
  return (sum rolls)

-- A more efficient version, which normalizes the distribution of dice
-- rolls at each recursive step to reduce the number of additions.
dn :: Int -> Int -> Dist Int
0 `dn` x = return 0
n `dn` x = do
  first <- die x
  rest  <- norm ((n-1) `dn` x)
  return (first + rest)
